import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EmpRegistrationFormComponent } from './emp-registration-form.component';

describe('EmpRegistrationFormComponent', () => {
  let component: EmpRegistrationFormComponent;
  let fixture: ComponentFixture<EmpRegistrationFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EmpRegistrationFormComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(EmpRegistrationFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
