import { Component, Input, Output,EventEmitter } from '@angular/core';

@Component({
  selector: 'app-parenttochilddemo',
  templateUrl: './parenttochilddemo.component.html',
  styleUrls: ['./parenttochilddemo.component.css']
})
export class ParenttochilddemoComponent {
  @Input() datafromparent : any = ' '
  

  @Output() valueChanged= new EventEmitter<string>();

  sendValue(e:any){
    this.valueChanged.emit(e.target.value);
  }

}
