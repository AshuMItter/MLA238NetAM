import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ParenttochilddemoComponent } from './parenttochilddemo.component';

describe('ParenttochilddemoComponent', () => {
  let component: ParenttochilddemoComponent;
  let fixture: ComponentFixture<ParenttochilddemoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ParenttochilddemoComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ParenttochilddemoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
