import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DemohostcompoComponent } from './demohostcompo.component';

describe('DemohostcompoComponent', () => {
  let component: DemohostcompoComponent;
  let fixture: ComponentFixture<DemohostcompoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DemohostcompoComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DemohostcompoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
