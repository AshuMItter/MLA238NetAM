import { Component,HostListener,HostBinding } from '@angular/core';

@Component({
  selector: 'app-demohostcompo',
  templateUrl: './demohostcompo.component.html',
  styleUrls: ['./demohostcompo.component.css']
})
export class DemohostcompoComponent {
  // @HostListener('click') onClick() {
  //   console.log('You clicked me!');
  // }

  // @HostListener('mouseleave') onLeave() {
  //   console.log('You clicked me!');
  // }
  @HostBinding('class.highlighted') isHighlighted = false;

  onMouseEnter() {
    this.isHighlighted = true;
  }

  onMouseLeave() {
    this.isHighlighted = false;
  }
  

  // counter = 0;
  // @HostListener('window:keydown.enter', ['$event'])
  // handleKeyDown(event: KeyboardEvent) {
  //   this.counter++;
  // }

  // @HostListener('window:keydown.Backspace', ['$event'])
  // handleBackspace(event: KeyboardEvent) {
  //   this.counter--;
  // }

  // resetCounter() {
  //   this.counter = 0;
  // }
}
