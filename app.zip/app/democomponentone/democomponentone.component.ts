import { Component, Input } from '@angular/core';
import { User } from './user.model';

@Component({
  selector: 'app-democomponentone',
  templateUrl: './democomponentone.component.html',
  styles: ['p {letter-spacing:10px}']
})
export class DemocomponentoneComponent 
{
  @Input() fromparent:any= ' '
   data = "I am a Paragraph !!";
   isDisabled = false;
   twowaybinding= "";

   user:User = {
    name:'',
    email:'',
    address:'',
    gender:''
   };

   onChanged(e:any){
   console.log(e.target.id);    
   console.log(this.fromparent);
 
   
  }
   logUser(e:any)
   {
    console.log(this.user);
   }
}
