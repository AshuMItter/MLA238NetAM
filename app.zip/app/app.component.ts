import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  items = ['apple', 'banana', 'orange'];
  title = 'demo-app';
  condition = false;
  parastyle = {
    color:'blue',
    letterSpacing:'10px'

  }
  selectedOption="option1";
  condition1 = true;
  onmouseEnter(){
   console.log('demo')
   this.parastyle.color='red';
   this.parastyle.letterSpacing='30px';
  }
 
  onmouseLeave()
  {
    this.parastyle.color='blue';
    this.parastyle.letterSpacing='10px';
  }
  childVal:any=''
  childValue(value:string){
   this.childVal = value;
   console.log(this.childVal);
  }
  datafromchildvariable:any='';
  handleDatafromChild(value:string){
  this.datafromchildvariable = value;
  console.log(this.datafromchildvariable);
  }
}
