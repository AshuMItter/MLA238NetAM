import { Component } from '@angular/core';
// import $ from 'jquery';
@Component({
  selector: 'app-dynamics',
  templateUrl: './dynamics.component.html',
  styleUrls: ['./dynamics.component.css']
})
export class DynamicsComponent {
 $: any;
textStyle={

  width:'30em',
  height:'3em',
  fontFamily:'arial',
  color:'black',
   boxShadow:'0 4px 6px -5px hsl(0, 0%, 40%), inset 0px 4px 6px -5px black',
   verticalAlign:'bottom'

   
};
textStyleTwo={

  width:'30em',
  height:'3em',
  fontFamily:'arial',
  color:'black',
  boxShadow:'0 4px 6px -5px hsl(0, 0%, 40%), inset 0px 4px 6px -5px black',
   verticalAlign:'bottom'
   
};


handleClick(){
   this.$('#txt1').hide(1000).show(1000);
}

}

