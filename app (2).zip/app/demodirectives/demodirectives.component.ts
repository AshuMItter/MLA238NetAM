import { Component } from '@angular/core';

@Component({
  selector: 'app-demodirectives',
  templateUrl: './demodirectives.component.html',
  styleUrls: ['./demodirectives.component.css']
})
export class DemodirectivesComponent {
  condition:boolean= true;

  count:number = 6;
  selectedOption='opt';
  continents:string[]=["Asia","Australia","Africa","Europe","Antarctica","America"]
  
  paraStyle={
    color:'red',
    letterSpacing:'10px'

  }
}
