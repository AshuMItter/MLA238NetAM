import { Component, ContentChild, ElementRef, Input, OnChanges, OnInit, QueryList, SimpleChanges, ViewChild } from '@angular/core';
import { NgModel } from '@angular/forms';

@Component({
  selector: 'app-child',
  templateUrl: './lifecompo.html'
})
export class ChildComponent implements OnInit, OnChanges {

  @ViewChild('Template',{static : false}) Template : ElementRef | undefined

  @ContentChild('ContentProjectionTemplate',{static : false}) ContentProjectionTemplate : ElementRef | undefined;
 
   @Input() valuesG : string = "";
  constructor() { }
    ngOnChanges(changes: SimpleChanges): void {
      console.log(changes['valuesG'].currentValue+" Current Property");
      console.log(changes['valuesG'].previousValue+" Previous Property");
      console.log(changes['valuesG'].firstChange);
      // console.log(changes.valuesG.currentValue);
        
        
    }

  btnPressed(e:any){
   console.log(e);
  }
  ngOnInit() {
  }

  ngAfterViewInit(){
    console.log("ngAfterViewInit")
    console.log(this.Template?.nativeElement); // Refer to -> Element Ref -> some object

    console.log(this.ContentProjectionTemplate?.nativeElement); // Refer to -> Element Ref -> some object
    //console.log(this.Template?.nativeElement);

    
    
}
  ngAfterContentInit() {
    console.log("ngAfterContentInit")
    console.log(this.Template?.nativeElement); // Refer to -> undefined  
    
    console.log(this.ContentProjectionTemplate?.nativeElement);// Refer to -> Element Ref -> some object
  }
  nama="";
}
