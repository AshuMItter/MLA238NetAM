import { AfterContentChecked, AfterContentInit, AfterViewChecked, AfterViewInit, Component, DoCheck, HostListener, OnChanges, OnDestroy, OnInit, SimpleChanges } from '@angular/core';
import { HostBinding } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent{ //implements OnInit,OnChanges,DoCheck,AfterContentInit,AfterContentChecked,AfterViewInit,AfterViewChecked,OnDestroy {
  constructor(){
   //console.log("constructor");
  }
  textvalues = "";
  //@ViewChild('myChild') childComponent: ChildComponent;

 
  @HostBinding('value') myValue:string | undefined = "default";
  @HostListener('click') clickIt(){
    //throw new Error('Error in Component Ts');
  }
  data="";
  items = ['apple', 'banana', 'orange'];
  title = 'demo-app';
  condition = false;
  parastyle = {
    color:'blue',
    letterSpacing:'10px'

  }
  selectedOption="option1";
  condition1 = true;

  onmouseEnter(){
   console.log('demo')
   this.parastyle.color='red';
   this.parastyle.letterSpacing='30px';
   throw new Error('Error in Component Ts');
   
  }
 
  onmouseLeave()
  {
    this.parastyle.color='blue';
    this.parastyle.letterSpacing='10px';
  }
  childVal:any=''
  childValue(value:string){
   this.childVal = value;
   console.log(this.childVal);
  }
  datafromchildvariable:any='';
  handleDatafromChild(value:string){
  this.datafromchildvariable = value;
  console.log(this.datafromchildvariable);
  }
}
