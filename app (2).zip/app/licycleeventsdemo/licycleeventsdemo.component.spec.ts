import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LicycleeventsdemoComponent } from './licycleeventsdemo.component';

describe('LicycleeventsdemoComponent', () => {
  let component: LicycleeventsdemoComponent;
  let fixture: ComponentFixture<LicycleeventsdemoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LicycleeventsdemoComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(LicycleeventsdemoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
