import { Injectable } from '@angular/core';
import { ErrorHandler } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class GlobalerrorhandlingService implements ErrorHandler {

  constructor() { }
  handleError(error: Error): void {
   
  alert(error.message+ ' I am being held at global error handling area');
  
  }
}
