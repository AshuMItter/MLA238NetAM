import { ErrorHandler, Injectable, NgZone } from "@angular/core";
import { HttpClient, HttpErrorResponse } from '@angular/common/http';

@Injectable({
    providedIn:"root"
})
export class GlobalErrorHandler implements ErrorHandler {
  constructor(
    //private errorDialogService: ErrorDialogService,
   
  ) {}

  handleError(error: Error) {
    // Check if it's an error from an HTTP response
    if (!(error instanceof HttpErrorResponse)) {
      error = error // get the error object
    }
    console.log(error)
     alert(
        error?.message+ " caught at global error handling" || 'Undefined client error ' 
        
      )
    

    console.error('Error from global error handler', error);
  }
}
