import { ErrorHandler, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FirstComponent } from 'src/firstc/first.component';
import { Binding } from 'src/BindingDemo/binding.component';
import { FormsModule } from '@angular/forms';
import { DemocomponentoneComponent } from './democomponentone/democomponentone.component';
import { ParenttochilddemoComponent } from './parenttochilddemo/parenttochilddemo.component';
import { DemohostcompoComponent } from './demohostcompo/demohostcompo.component';
import { ChildtoparentcomponentComponent } from './childtoparentcomponent/childtoparentcomponent.component';
import { DemodirectivesComponent } from './demodirectives/demodirectives.component';
import { DemohostComponent } from './demohost/demohost.component';
import { GlobalErrorHandler } from './globalerror/globalerror.service';
import { LifecycledemoComponent } from './lifecycledemo/lifecycledemo.component';
import {ChildComponent} from './lifecompo/lifecompo';
import { HostbindingComponent } from './hostbinding/hostbinding.component'
import { GlobalerrorhandlingService } from './globalerrorhandling.service';
import { LicycleeventsdemoComponent } from './licycleeventsdemo/licycleeventsdemo.component';
import { DynamicsComponent } from './dynamics/dynamics.component';
@NgModule({
  declarations: [
    AppComponent,
    FirstComponent,
    Binding,
    DemocomponentoneComponent,
    ParenttochilddemoComponent,
    DemohostcompoComponent,
    ChildtoparentcomponentComponent,
    DemodirectivesComponent,
    DemohostComponent,
    LifecycledemoComponent,
    ChildComponent,
    HostbindingComponent,
    LicycleeventsdemoComponent,
    DynamicsComponent
    

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule
  ],
  //providers: [{provide:ErrorHandler, useExisting:GlobalerrorhandlingService}],
  providers:[],
  bootstrap: [AppComponent]
})
export class AppModule { }
