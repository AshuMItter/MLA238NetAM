﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FirstProgram
{
    internal class BuilderPattern
    {
    }
    public class Computer
    {
        public string HardDrive { get; set; }
        public string Ram { get; set; }
        public string Cpu { get; set; }

        public override string ToString()
        {
            return $"Computer: HardDrive={HardDrive}, Ram={Ram}, Cpu={Cpu}";
        }
    }

    public abstract class ComputerBuilder
    {
        protected Computer computer = new Computer();

        public abstract void BuildHardDrive();
        public abstract void BuildRam();
        public abstract void BuildCpu();

        public Computer GetComputer()
        {
            return computer;
        }
    }

    public class GamingComputerBuilder : ComputerBuilder
    {
        public override void BuildHardDrive()
        {
            computer.HardDrive = "1TB SSD";
        }

        public override void BuildRam()
        {
            computer.Ram = "32GB DDR5";
        }

        public override void BuildCpu()
        {
            computer.Cpu = "Intel Core i9";
        }
    }

    public class OfficeComputerBuilder : ComputerBuilder
    {
        public override void BuildHardDrive()
        {
            computer.HardDrive = "500GB HDD";
        }

        public override void BuildRam()
        {
            computer.Ram = "8GB DDR4";
        }

        public override void BuildCpu()
        {
            computer.Cpu = "Intel Core i5";
        }
    }

    public class ComputerDirector
    {
        private ComputerBuilder builder;

        public ComputerDirector(ComputerBuilder builder)
        {
            this.builder = builder;
        }

        public void ConstructComputer()
        {
            builder.BuildHardDrive();
            builder.BuildRam();
            builder.BuildCpu();
        }
    }

}
