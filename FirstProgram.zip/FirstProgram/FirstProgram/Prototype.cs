﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FirstProgram
{
    internal class Prototype
    {
    }
    

interface ICloneable<T>
    {
        T Clone();
    }

    class Car : ICloneable<Car>
    {
        public string Model { get; set; }
        public string Color { get; set; }

        public Car(string model, string color)
        {
            Model = model;
            Color = color;
        }

        public Car Clone()
        {
            // Shallow copy by default
            return (Car)MemberwiseClone();
        }
    }

    //class Program
    //{
    //    static void Main()
    //    {
    //        Car car1 = new Car("Sedan", "Blue");
    //        Car car2 = car1.Clone();

    //        car2.Color = "Red";

    //        Console.WriteLine(car1.Model + " " + car1.Color); // Output: Sedan Blue
    //        Console.WriteLine(car2.Model + " " + car2.Color); // Output: Sedan Red
    //    }
    //}

}
