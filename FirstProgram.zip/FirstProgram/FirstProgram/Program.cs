﻿


using System.Net;
using System.Net.Http.Headers;
using System.Net.NetworkInformation;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Transactions;
using System.Xml.Linq;

namespace FirstProgram
{

   





    public class MyClass
    {
       public static int a = 56;
        public int d = 89;
        static MyClass()
        {
            Console.WriteLine("Static constructor called.");
        }
    }
    class TechnicalScripter
    {

        // variables
        private string topic_name;
        private int article_no;

        // parameterized constructor
        public TechnicalScripter(string topic_name, int article_no)
        {
            this.topic_name = topic_name;
            this.article_no = article_no;
        }

        // copy constructor
        public TechnicalScripter(TechnicalScripter tech)
        {
            topic_name = tech.topic_name;
            article_no = tech.article_no;
        }

        // getting the topic name and 
        // number of articles published
        public string Data
        {

            get
            {
                return "The name of topic is: " + topic_name +
                       " and number of published article is: " +
                                        article_no.ToString();
            }
        }
    }
    class Person1
    {
        public int Age { get; set; }
        public string Name { get; set; }
        public Address1 Address { get; set; } // Reference type
    }

    class Address1
    {
        public string Street { get; set; }
        public string City { get; set; }
    }


    class Person2
    {
        public int Age { get; set; }
        public string Name { get; set; }
        public Address1 Address { get; set; }

        public Person2 DeepCopy()
        {
            Person2 clone = (Person2)this.MemberwiseClone();
            clone.Address = new Address1 { Street = this.Address.Street, City = this.Address.City };
            return clone;
        }
       ~ Person2()
        {
           
        }
    }
    class Parent
    {
        internal int parentAge = 100;
        public Parent()
        {
            //Console.WriteLine("Parent Constructor Called...");
        }
       // public abstract void DemoAbstract();

        public virtual void DemoVirtual()
        {
            Console.WriteLine("Demo Virtual from Parent Class called "); 
        }
    }

     class  Child : Parent
    {
        public Child()
        {
            //Console.WriteLine("Child Constructor Called...");
        }

        //public override void DemoAbstract()
        //{
        //    Console.WriteLine("Abstract Method from Child Class");
            
        //}
        public override void DemoVirtual()
        {
            //base.DemoVirtual();
            Console.WriteLine("Demo Virtual Method from Child Class called...");
        }

        public void Show()
        {
            Console.WriteLine("Show something from child");
        }
    }

  sealed class  SubChild : Child
    {
        new public void Show()
        {
            Console.WriteLine("Show something from sub-child");
        }
        public override void DemoVirtual()
        {
            Console.WriteLine("Demo Virtual called from SubChild");
            //parentAge
        }
    }

    class MyString : System.Object
     {
        public override string ToString()
        {

            return "Demo";
            
          
        }
    }

    public class Process
    {
        public Process()
        {
            Console.WriteLine("Process Contstructor Started...");
        }

       ~ Process()
        {

        }
        
    }
    interface IFace
    {
        string DemoMethod()
        {
            return "Hello World";
        }
    }
    static class MyStaticClass
    {
      public  static int age = 100;

        public static void Function()
        {
            Console.WriteLine("Function");
        }


    }

    class DemoStaticCons
    {
       public static int age = 100;

        public int parent_age = 50;
        public DemoStaticCons()
        {
            Console.WriteLine("Intance Constructor called..");
        }
        static DemoStaticCons()
        {
            Console.WriteLine("Static constructor called");
        }

        public static void StaticMethod()
        {
            Console.WriteLine("Static Method called...");
        }
    }


    public class DemoParent
    {
        public void Show()
        {
            Console.WriteLine("Show from DemoParent");
        }
    }
    public class DemoChild : DemoParent
    {
        new public void Show()
        {
            Console.WriteLine("Show from Demo Child");
        }
    }
    //public interface IShape
    //{
    //    // Method
    //    double CalculateArea();

    //    // Property
    //    int NumberOfSides { get; }

    //    // Event
    //    event EventHandler ShapeChanged;

    //    // Indexer
    //    double this[int index] { get; } // Assuming shape has points
    //}


    interface IPerson
    {
        const bool isLiving = true;
        // method
        void PrintFullName();

        // properties
        string Fname { get; set; }

        void OneMoreMethod()
        {
            Console.WriteLine("OneMoreMethod()");
        }
       

    }

    public class Student : IPerson
    {
       
        public string Fname { get ; set ; }

        public void PrintFullName()
        {
            Console.WriteLine("Hi I am Student and My name is Charu !");
        }
    }

    public class Athlete : IPerson
    {
        public string Fname { get ; set ; }

        public void PrintFullName()
        {
            Console.WriteLine("Hi I am Athelete and My name is Rajak !");
        }
    }

    class DemoInterface
    {
       static public IPerson DemoMethod()
        {
            return new Student();

        }
    }


    class Dummy : IPerson
    {
        public string Fname { get; set; }

        public void PrintFullName()
        {
            Console.WriteLine("Dummy for testing purpose ...");
        }
    }








    internal class Program
    {

        static void DemoPerson(IPerson athlete)
        {
            Console.WriteLine("I am DemoPerson Method runnin...");
            athlete.PrintFullName();
        }

        public static double Add(double x,double y)
        {
            return x + y;
        }
        public static int Add(int x,int y)
        {
            return x + y;
        }
        public static int Add(int x, int y,int z)
        {
            return x + y;
        }        public int Add(int x, double y, int z)
        {
            return x + z;
        }
        public static int Add(double x, int y, int z)
        {
            return y + z; 
        }

        static void DisplayMessage(string message="default", int repeatCount = 2)
        {
            for (int i = 0; i < repeatCount; i++)
            {
                Console.WriteLine(message);
            }
        }

        static void DisplayTheMessage(int? num1=20, int num2=10)
        {
            int? result = num1 + num2;

            Console.WriteLine(result);
        }






        interface IBasicChannels
        {
            void BasicChannels();
        }

        interface IIntermediateChannels
        {
            void IntermediateChannels();    
        }

        interface IHdChannels
        {
            void HdChannels();  
        }

       

        class Channels : IBasicChannels, IIntermediateChannels, IHdChannels
        {
            public void BasicChannels()
            {
                Console.WriteLine("Basic Channels");
            }

            public void HdChannels()
            {
                Console.WriteLine("Hd Channels");
            }

            public void IntermediateChannels()
            {
                Console.WriteLine("Intermediate Channels");
            }
        }

        public class BasicChannel : IBasicChannels
        {
            public void BasicChannels()
            {
                Console.WriteLine("Basic Channels");
            }
        }

        public class IntermediateChannels : IIntermediateChannels
        {
            void IIntermediateChannels.IntermediateChannels()
            {
                Console.WriteLine(  "Intemediate Channels");
            }
        }

        public class HdChannels : IHdChannels
        {
            void IHdChannels.HdChannels()
            {
                
            }
        }

      public  class DemoPrivateCons
        {
            private DemoPrivateCons()
            {

            }
            public static DemoPrivateCons GetSingleton
            {
                get { return new DemoPrivateCons(); }   
            
            }

         }

        class Data
        {
            public int MyProperty { get; set; }

            public string MyProperty1 { get; set; }

            public double MyProperty2 { get; set; }
        }

        enum Demo : long
        {
            mon,
            tue
        }

      
        //<access modifier> <delegate> <return type> <name of delegate><params>

        public delegate int AnyNamedDelegate(int x, int y);

        public delegate int PerformCalculation(int x, int y);


        public static void Calc(int x, int y)
        {
            

            int result = x + y;
            Console.WriteLine(result);
        }
        public static void Calc1(int x, int y)
        {
            int result = x + y;
            Console.WriteLine(result);
        }

        public static void DemoDelegates(PerformCalculation perf)
        {
            perf.Invoke(100, 100);   
        }

        public static PerformCalculation DemoDelegates1()
        {
            return delegate (int x, int y)
            {
                int result = x + y;
                return result;
            };
        }
        public static void Method1TobeReferencedByAnyDelegate(int x, int y)
        {
            int result = x + y;
            Console.WriteLine(result);
        }

        public class Demonstrations
        {
            public  int MyProperty3 { get; init; }


            public Demonstrations(string name)
            {
                MyProperty3 = 34;
            }

            static Demonstrations()
            {
               
            }
            public required int  MyProperty { get; set; }

            public int MyProperty1 { get; set; }

            public int MyProperty2 { get; set; }

           
        }
       public enum MyEnum 
        {
            None = 0,
            First,
            Second,
            Third,
            Fourth,
            Fifth,
            Sixth,
            Seventh,
            Eight,
            Nineth,
            Tenth
        }
        static void Main(string[] args)
        {

            Console.WriteLine(Convert.ToUInt32(MyEnum.Second));
            Console.WriteLine(MyEnum.Fourth);

            Demonstrations demons = new Demonstrations("DemoName")
            {
                MyProperty = 67
                           };

           if (Convert.ToInt32(MyEnum.Fourth) ==  4)
            {

            }

            // tuples 
            //var t = (1, 'C', 23.45f, 222.444m, 34.67, 60000, 34, 8,"string value", 9, 10);

            //Console.WriteLine(t.Item2);

            //t.Item2 = 'A';

            // destructuring of tupple
            //var tupple = ("post offfice", 567);

            //var (office,size) = tupple;

            //Console.WriteLine(office);

            //Console.WriteLine(size);



           // Console.WriteLine(t.Item2);


            //(int max,int min) FindMaxorMin(int value)
            //{
            //    return (100,100);
            //}


            //var tu = FindMaxorMin(12);

            //Console.WriteLine(tu.min);
            //Console.WriteLine(tu.max);


            //(double Sum, int Count) t2 = (4.5, 3);

            //Console.WriteLine($"Sum of {t2.Count} elements is {t2.Sum}.");


            //const double pi = 3.14;

            //var anonArray = new[] { new { name = "apple", diam = 4 }, new { name = "grape", diam = 1 } };

            //foreach (var item in anonArray)
            //{
            //    Console.WriteLine(item.name);
            //    Console.WriteLine(item.diam);
            //}

            //PerformCalculation performCalculation = Calc;
            //performCalculation += Calc1;

            ////performCalculation(100, 100);

            //DemoDelegates(performCalculation);         

            //PerformCalculation perf = DemoDelegates1();


            // normal method
            // AnyNamedDelegate referer = Method1TobeReferencedByAnyDelegate;


            // anonymous methods
            //referer = delegate (int x, int y)
            //{
            //    int result = x + y;
            //    Console.WriteLine(result);
            //};

            // lambdas expression
            //AnyNamedDelegate referer = (x, y) =>
            //{

            //    return x + y;
            //};

            //var anomymousType = new { name = "Some name", age = 78 };

            //Console.WriteLine(anomymousType.age);
            //Console.WriteLine(anomymousType.name);




            //  referer(200, 200);





            // referer.Invoke(100, 100);

            //PerformCalculation  perf = delegate (int x, int y)
            //{
            //    return x + y;
            //};

            //perf = (x, y) => x + y;


            //perf.Invoke(50, 100);













            // int[] demos = { 1, 1, 1, 1, };


            // string data = "TheCountofmycharrachtersis28";

            //Console.WriteLine(data.WordCount());
            //DemoMethods demoMethods = new DemoMethods();
            //demoMethods.DemoMethodFour();


            //Console.WriteLine(Demo.mon);

            //Console.BackgroundColor = ConsoleColor.Blue;
            //Console.ForegroundColor = ConsoleColor.Red;
            //Console.Clear();
            //while (true)
            //{
            //    Console.WriteLine("Kindly select the option from the list below :");
            //    Console.WriteLine("Press 0 for creating new Entry");
            //    Console.WriteLine("Press 1 for deleting an Entry");
            //    Console.WriteLine("Press 2 for updating an Entry");
            //    Console.WriteLine("Press 3 for listing all the Entries");

            //    int switch_Choice = Convert.ToInt32(Console.ReadLine());
            //    DataManagement management = new DataManagement();   

            //    switch (switch_Choice)
            //    {
            //        case 0:
            //           // Console.WriteLine("You selected option 0");
            //            management.CreateData();
            //            break;
            //        case 1:
            //            Console.WriteLine("You selected option 1");
            //            break;
            //        case 2:
            //            Console.WriteLine("You selected option 2");
            //            break;
            //        case 3:
            //            Console.WriteLine("You selected option 3");
            //            break;

            //        default:
            //            break;
            //    }
            //}



            //Data data = new Data();
            //data.MyProperty1 = "";
            //data.MyProperty = 23;
            //data.MyProperty2 = 34.56;
            //Data[] datas = new Data[23];

            //IHdChannels[] hdChannels = new IHdChannels[23];

            //hdChannels[0] = new HdChannels();



            //datas[0] = data;




            //DemoPrivateCons con = DemoPrivateCons.GetSingleton;


            //IHdChannels channels = new Channels();

            //channels.HdChannels();

            //IIntermediateChannels intermediateChannels = new Channels();

            //intermediateChannels.IntermediateChannels();


            //IBasicChannels basicChannels = new Channels();

            //basicChannels.BasicChannels();


            //if (basicChannels is Channels)
            //{
            //    Console.WriteLine(true);
            //}
            //else
            //{
            //    Console.WriteLine(false);
            //}





            //DisplayTheMessage("My name is LorumIpsum");

            //IPerson referencer =   DemoInterface.DemoMethod(); 

            //referencer.PrintFullName(); 

            //DisplayTheMessage();
            ////DemoPerson(new Student());
            ////DemoPerson(new Athlete());

            //DemoPerson(new Dummy());
            //IPerson person = new Dummy();

            //person.OneMoreMethod();


            // Console.WriteLine(Program.Add(123.45, 2345.89));
            // DisplayMessage(repeatCount: 10, message: "hello world");
            //DemoParent parent = new DemoParent();
            //parent.Show();
            //DemoParent demoParent = new DemoChild();
            //demoParent.Show();  

            //string isImuttable = "DEMO";

            //StringBuilder sb = new StringBuilder("Demo ");

            //SubChild subChild = new SubChild();
            //subChild.Show();

            //Child chd = new SubChild();
            //chd.Show();


            //for (int i = 0; i < 1000000; i++)
            //{

            //sb.AppendLine("Line appended");

            //Console.WriteLine(sb.ToString());

            // }

            // string val = isImuttable.Split(',')[0];

            //Console.WriteLine(isImuttable.First(x => x == 'd'));

            //string[] days = { "Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun" };



            //foreach (var item in days)
            //{
            //    Console.WriteLine(item);
            //} 



            //Console.WriteLine(isImuttable.ToCharArray());

            //foreach (var item in isImuttable.ToCharArray())
            //{
            //    Console.Write(item);
            //}

            //foreach (var item in isImuttable.Split(' '))
            //{
            //    Console.WriteLine($"{item}");
            //}


            //StringBuilder sb  = new StringBuilder("Demo ");
            //sb.AppendLine("Line appended");

            //Console.WriteLine(sb.ToString());   



            // Mathematics math = new Mathematics();   
            // int[] arr = null;

            // int? reultatZeroPlace = arr?[0];
            // int? x = 50;

            //Console.WriteLine(math.Add(x ??= 10, 50));



            //TechnicalScripter tc = new TechnicalScripter("Pythagoras Theram",100);

            //Console.WriteLine(tc.Data);

            //TechnicalScripter tcCopyc = new TechnicalScripter(tc);

            //Console.WriteLine(tcCopyc.Data);

            //Console.WriteLine(DemoStaticCons.age);

            //DemoStaticCons.StaticMethod();

            //Console.WriteLine(DemoStaticCons.age);

            //DemoStaticCons demoStaticCons = new DemoStaticCons();

            //demoStaticCons.parent_age = 75;

            //DemoStaticCons demoStaticCons1 = new DemoStaticCons();

            //DemoStaticCons demoStaticCons2 = new DemoStaticCons();


            // SubChild sub_child = new SubChild();
            // Console.WriteLine(sub_child.parentAge);





            //Person2 person1 = new Person2 { Age = 30, Name = "Alice", Address = new Address1 { Street = "123 Main St", City = "Anytown" } };
            //Person2 person2 = person1.DeepCopy();

            //person2.Name = "Bob";
            //person2.Address.Street = "456 Elm St";

            //Console.WriteLine(person1.Name); // Output: Alice
            //Console.WriteLine(person1.Address.Street); // Output: 123 Main St

            //TechnicalScripter technicalScripter = new TechnicalScripter("Pythagoras Theoram",100);

            //TechnicalScripter t2 = new TechnicalScripter(technicalScripter);
            //Console.WriteLine(t2.Data);

            //Person1 person1 = new Person1 { Age = 30, Name = "Alice", Address = new Address1 { Street = "123 Main St", City = "Anytown" } };
            //Person1 person2 = person1; // Shallow copy

            //person2.Name = "Bob";
            //person2.Address.Street = "456 Elm St";

            //Console.WriteLine(person1.Name); // Output: Bob
            //Console.WriteLine(person1.Address.Street); // Output: 456 Elm St


            //  int? count = null;
            //  count = 10; // count will be 10

            //  Mathematics mathematics = new Mathematics();
            //  int? a = null;

            //Console.WriteLine(mathematics.Add(a ??= 12, 20));

            //Console.WriteLine(count);


            //int?[] arrays = null;

            //int? firstVal = arrays[0];

            //Mathematics maths = null;

            //var result = maths?.name;

            //Console.WriteLine(firstVal.ToString()); 


            //Console.WriteLine(MyClass.a);
            //MyClass st = new MyClass();
            //MyClass st1= new MyClass();
            //Console.WriteLine(st1.d);

            //Person p = new Person("Daniel", 50);
            //p.DisplayNameAndAge();
            //Console.WriteLine($"{p.Name} : Name");
            //Console.WriteLine($"{p.Age} : Age");
            //p.Name = "Danielle";
            //p.Age = 78;
            //Console.WriteLine($"{p.Name} : Name");
            //Console.WriteLine($"{p.Age} : Age");



            //int a = 10;
            //int b = 15;
            //Console.WriteLine($"Before Swap a:{a} and b :{b}");
            //Mathematics.Swap(ref a, ref b);
            //Console.WriteLine($"After Swap a:{a} and b :{b}");

            //bool val =   Mathematics.TryParseInt("123",out var result);
            //Console.WriteLine($" resultFromTryParse:{val} and Other returned value is :{result}");

            //string val = "demo";
            //int result = 0;

            //  bool isitorNotcovertable =  int.TryParse(val, out  result);




            //Console.WriteLine($"is it convertible: {isitorNotcovertable} and value of out result is: {result}");

            // Convert.ToInt32(val);   

            // Ex : Use loops to generate number whereby the max range is given by user
            //      to find out even numbers and odd numbers ( print those)
            //      Re-do these with arrays

            //string name=null;
            //int age = 100;
            //string message = name ?? "Unknown";
            //Console.WriteLine(message);

            // short hand for if else 

            //string result = name is null ? "yes" : "no";

            //string resultNumeric = age < 50 ? "yes" : "no";

            //Console.WriteLine(result+ " name is numm");

            //Console.WriteLine(resultNumeric+" age < 50");


            //Mathematics maths = new Mathematics();

            //if(maths is Mathematics)
            //{
            //    Console.WriteLine("yes");
            //}
            //else
            //{
            //    Console.WriteLine("No");
            //}
            //if (23 is int)
            //{
            //    Console.WriteLine(  "yes");
            //}
            //else
            //{
            //    Console.WriteLine("no"); 
            //}

            //Console.WriteLine(result);
            //int size = 10;
            //Console.WriteLine("Please enter youe age ");
            //size = Convert.ToInt32(Console.ReadLine());            

            //switch (size)
            //{
            //    case 15:
            //        Console.WriteLine("Hello Your age is 15 years");
            //        break;
            //        case 20:
            //        Console.WriteLine("Hello Your age is 20 years");
            //        break;
            //    default:
            //        Console.WriteLine("You are not eligible");
            //        break;
            //}
            //int a = 10;
            //int ctr = 0;
            //do
            //{
            //    Console.WriteLine(ctr);
            //    ctr++;
            //} while ( ctr > a);





            //int a = 10, b = 20;
            //Mathematics.Swap(a, b);
            //Console.WriteLine("a = " + a); // Output: 20
            //Console.WriteLine("b = " + b); // Output: 10

            //string input = "123";
            //int number;
            //if (Mathematics.TryParseInt(input, out number))
            //{
            //    Console.WriteLine("Parsed number: " + number);
            //}
            //else
            //{
            //    Console.WriteLine("Invalid input");
            //}

            // Findout the Even and Odd number if the number is taken from
            // user 


            //int num = 10;
            //object obj = num; // Boxing: int to object
            //Console.WriteLine(obj);
            //int num2 = (int)obj; // Unboxing: object to int
            //Console.WriteLine(num2);

            //int a = 100, b = 100;
            //bool isGreater = a > b; // Greater than
            //Console.WriteLine(a + ">" + b + " : isGreater :" + isGreater);

            //bool isLess = a < b; // Less than
            //Console.WriteLine(a + "<" + b + " : isLess :" + isLess);

            //bool isEqual = a == b; // Equal to
            //Console.WriteLine(a + "==" + b + " : isEqual :" + isEqual);

            //bool isNotEqual = a != b; // Not equal to
            //Console.WriteLine(a + "!=" + b + " : isNotEqual :" + isNotEqual);

            // bool x = true, y = false;
            //bool andResult = x && y; // Logical AND
            //Console.WriteLine(andResult);

            //bool orResult = x || y; // Logical OR
            //Console.WriteLine(orResult);

            //bool notResult = !x; // Logical NOT
            //Console.WriteLine(notResult);


            //if (!y)
            //{
            //    Console.WriteLine("All true");
            //}
            //else
            //{
            //    Console.WriteLine("All not true");
            //}


            //int a = 10, b = 5;
            //int sum = a + b; // Addition
            //Console.WriteLine(sum);
            //int difference = a - b; // Subtraction
            //Console.WriteLine(difference);
            //int product = a * b; // Multiplication
            //Console.WriteLine(product);



            //int quotient = a / b; // Division
            //Console.WriteLine(quotient);
            //int remainder = a % b; // Modulus
            //Console.WriteLine(remainder);

            //Console.WriteLine(Math.Pow(10, 4));



            //int[] ints = new int[10];
            //ints[0] = 89;

            // int[] ints2 = { 1, 2, 3, 4, 5, 6 };

            //var int1 = 78;
            //var int2 = 100;
            //var int3 = int1 + int2;

            //dynamic demo = 67;

            //demo.DoSomething();

            //foreach (var item in ints2)
            //{
            //    Console.WriteLine(item);
            //}


            //foreach (var item in ints2)
            //{
            //    Console.WriteLine(item);
            //}



            //int[,] matrix = new int[2,2];

            //int[,] matrix2 = { 
            //    {1,2 }, 

            //    {3,4 } 
            //};            


            //matrix[0,0] = 1;
            //matrix[0,1] = 2;
            //matrix[1,0] = 3;
            //matrix[1,1] = 4;


            //int[,,] matrix3d = new int[2,2,2];

            //matrix3d[0,0, 0] = 1;
            //matrix3d[0,0, 1] = 2;
            //matrix3d[1,1, 0] = 3;
            //matrix3d[2,1, 1] = 4;



            //int[,,] matrix = new int[2, 2, 3]; // 2 rows, 3 columns
            //matrix[0,0, 0] = 1;
            //matrix[1, 1, 2] = 9;

            //int[][] jaggedArray = new int[3][];
            //jaggedArray[0] = new int[2];
            //jaggedArray[1] = new int[3];
            //jaggedArray[2] = new int[1];

            //jaggedArray[0][1] = 0;
            //jaggedArray[1][1] = 23;
            //jaggedArray[2][1] = 0;


            //string val = "values";
            string? val2 = null;

            int? val3 = null;

            double? val4 = null;    
            


            Console.WriteLine(val4); 
            

            //string? name = "default";
            //Console.WriteLine("Please enter your name .");           
            //name = Console.ReadLine();
            //Console.WriteLine("Hello, World to "+name+" !");
            //while (true)
            //{
            //    Mathematics maths = new Mathematics();
            //    //Console.WriteLine("Please enter first Number");
            //    maths.WriteToScreenFN();
            //    int num1 = Convert.ToInt32(Console.ReadLine());
            //    //Console.WriteLine("Please enter second number");
            //    maths.WriteToScreenSN();
            //    int num2 = Convert.ToInt32(Console.ReadLine());


            //    int multiplication = maths.Add(num1, num2);

            //    Console.WriteLine("The multiplication result is : " + multiplication);
            //}




        }
    }
    class PersonalDetails
    {
        public PersonalDetails()
        {

        }
        public string Name { get; set; }
        public int Id { get; set; }
        public string FirstName { get; set; }
        = "default";
        public string LastName { get; set; }
        = "default";
        
    }
}
