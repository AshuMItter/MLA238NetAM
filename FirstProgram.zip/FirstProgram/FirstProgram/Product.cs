﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata.Ecma335;
using System.Text;
using System.Threading.Tasks;

namespace FirstProgram
{
   

    internal class Person
    {
        
        // backing variable
         string name = "default";

         int age = 25;


        public string DataNames
        {
            get;
            init;
        }
        public string Name {

            get { return name; }
            set {

                if (value.Contains('b'))
                {
                    name = value;
                }
                else
                {
                    throw new ArgumentException("something... something...");
                }
            
            } 
        
        
        }

        // auto implemented property
       // public int MyProperty { get; set; }

        // expression bodied
        public int MyProperty { get; } = 32;

        // readonly property
        public string Name1
        {

            get { return name; }
            //set { name = value; }


        }

        public int Age { get { return age; } set { age = value; } }


        public Person(string name, int age) { 
         this.name = name;
         this.age = age;
            this.DataNames = "val";
        
        }  

        public void DisplayNameAndAge()
        {
            Console.WriteLine($"Name is : {name} and Age is {age}");
           
        }


    }
}
