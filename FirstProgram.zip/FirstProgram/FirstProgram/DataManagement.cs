﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FirstProgram
{
    class Students
    {
        public int? Id { get; set; } 
        public string? Name { get; set; }
    }
    internal class DataManagement
    {
        static Students[] students = new Students[20];
        public DataManagement() { }

        public void CreateData()
        {
            Console.WriteLine("Please enter your name");
            string name = Console.ReadLine();

            var student = new Students()
            {
                Id = 1,
                Name = name
            };
           
            for (int i = 0; i < students.Length; i++) {
                if (students[i] == null)
                {
                    students[i] = student;
                    break;
                }              
            
            }

            //int deleteUser = 2;
            //for (int i = 0; i < students.Length; i++)
            //{
            //    if (students[i].Id == deleteUser)
            //    {
            //        students[i] = null;
            //        break;
            //    }
            //}

            foreach (var item in students)
            {
                if(item != null) {
                    Console.WriteLine(item.Name);
                }
            }
        }
    }
}
