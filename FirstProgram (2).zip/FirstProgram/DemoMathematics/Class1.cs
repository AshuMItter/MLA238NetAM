﻿namespace DemoMathematics
{
    public class Class1
    {
         public double DemoMaths(double d) { return d * d + d * 100; }    
    }
}
