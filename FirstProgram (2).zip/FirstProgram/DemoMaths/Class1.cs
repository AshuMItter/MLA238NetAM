﻿namespace DemoMaths
{
    public class Mathmatics
    {
        public double Exponentialize(double d)
        {
            return d * d + 100 * 200;
        }

    }
}
