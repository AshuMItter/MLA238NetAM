﻿namespace DemoAssmbly
{
    public class Class1
    {
        public void DoWork()
        {
            Console.WriteLine("Hello World !");
        }
    }
}
