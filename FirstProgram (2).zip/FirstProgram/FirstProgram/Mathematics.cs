﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FirstProgram
{
    internal class Mathematics
    {
      public  string name = "demo";
        public void WriteToScreenFN()
        {
            Console.WriteLine("H! Welcome to the Program");
            Console.WriteLine("Please enter first number");
        }
          
        public void WriteToScreenSN()
        {
            Console.WriteLine("Please enter Second number");
        }
        public int? Add(int? x, int y)
        {
            return x + y;
        }

       //<encapsulation text> <modifiers> <returntype> <nameoffuncn>( <datatype> params1, <datattype param2>){
       //  return <datatype>
       //}
       public static void Swap(ref int x,ref int y)
        {
            int temp = x;
            x = y;
            y = temp;
        }
       public static bool TryParseInt(string str, out int result)
        {
            result = 20;

        

            return true;
            
            //bool success = int.TryParse(str, out result);
            //return success;
        }


    }
}
