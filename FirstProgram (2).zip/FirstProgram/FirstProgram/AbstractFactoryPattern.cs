﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FirstProgram
{

   public interface IShape1
    {
        void Draw();
    }
   public interface IColor
    {
        void Fill();
    }

    public class Rectangle : IShape1
    {
        public void Draw()
        {
            Console.WriteLine("Rectangle is being drawn...");
        }
    }

    public class Circle1 : IShape1
    {
        public void Draw()
        {
            Console.WriteLine("Circle is being drawn...");
        }
    }

    public class Red : IColor
    {
        public void Fill()
        {
            Console.WriteLine("Filling red color..");
        }
    }

    public class Green : IColor
    {
        public void Fill()
        {
            Console.WriteLine("Filling green color..");
        }
    }

    public abstract class AbstractFactory
    {
        public abstract IColor GetColor();
        public abstract IShape1 GetShape();

    }

    public class DrawShapeA : AbstractFactory
    {
        public override IColor GetColor()
        {
            return new Green();
        }

        public override IShape1 GetShape()
        {
           return new Rectangle();
        }
    }

    public class DrawShapeB : AbstractFactory
    {
        public override IColor GetColor()
        {
            return new Green();
        }

        public override IShape1 GetShape()
        {
            return new Circle1();
        }
    }



}
