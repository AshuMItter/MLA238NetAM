﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FirstProgram
{

   public interface IDocument
    {
        void GetDocument();   
    }

    public class PDFDocument : IDocument
    {
        public void GetDocument()
        {
            Console.WriteLine("This is PDF version being rendered");
        }
    }
    public class WordDocument : IDocument
    {
        public void GetDocument()
        {
            Console.WriteLine("This is Word version being rendered");
        }

    }

    public class Factory
    {
        public IDocument GetMeTheDocument(string typeOfDocument)
        {
            switch (typeOfDocument)
            {
                case "pdf":
                    return new PDFDocument();
                        break;

                case "word":
                    return new WordDocument();
                    break ;

                default:
                    throw new Exception("This type is not available");
                    break;
            }
        }
    }

    internal class FactoryMethodPattern
    {

    }
}
