﻿


//using System.Collections;
//using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.Drawing;
using System.Net;
using System.Net.Http.Headers;
using System.Net.NetworkInformation;
using System.Runtime.CompilerServices;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Transactions;
using System.Xml.Linq;
using static FirstProgram.Program;
using System;
using System.Linq;
using System.Collections.Generic;
using System.Collections;
using DemoDLL;
using System.Text.RegularExpressions;
using System.Linq;
using System.Runtime.InteropServices;
//using System.Windows.Forms;
//using Microsoft.FSharp.Linq.RuntimeHelpers;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.IO;

namespace FirstProgram
{

   

    public class MyClass
    {

        
       public static int a = 56;
        public int d = 89;
        static MyClass()
        {
            Console.WriteLine("Static constructor called.");
        }
    }
    class TechnicalScripter
    {

        // variables
        private string topic_name;
        private int article_no;

        // parameterized constructor
        public TechnicalScripter(string topic_name, int article_no)
        {
            this.topic_name = topic_name;
            this.article_no = article_no;
        }

        // copy constructor
        public TechnicalScripter(TechnicalScripter tech)
        {
            topic_name = tech.topic_name;
            article_no = tech.article_no;
        }

        // getting the topic name and 
        // number of articles published
        public string Data
        {

            get
            {
                return "The name of topic is: " + topic_name +
                       " and number of published article is: " +
                                        article_no.ToString();
            }
        }
    }
    class Person1
    {
        public int Age { get; set; }
        public string Name { get; set; }
        public Address1 Address { get; set; } // Reference type
    }

    class Address1
    {
        public string Street { get; set; }
        public string City { get; set; }
    }


    class Person2
    {
        public int Age { get; set; }
        public string Name { get; set; }
        public Address1 Address { get; set; }

        public Person2 DeepCopy()
        {
            Person2 clone = (Person2)this.MemberwiseClone();
            clone.Address = new Address1 { Street = this.Address.Street, City = this.Address.City };
            return clone;
        }
       ~ Person2()
        {
           
        }
    }
    class Parent
    {
        internal int parentAge = 100;
        public Parent()
        {
            //Console.WriteLine("Parent Constructor Called...");
        }
       // public abstract void DemoAbstract();

        public virtual void DemoVirtual()
        {
            Console.WriteLine("Demo Virtual from Parent Class called "); 
        }
    }

     class  Child : Parent
    {
        public Child()
        {
            //Console.WriteLine("Child Constructor Called...");
        }

        //public override void DemoAbstract()
        //{
        //    Console.WriteLine("Abstract Method from Child Class");
            
        //}
        public override void DemoVirtual()
        {
            //base.DemoVirtual();
            Console.WriteLine("Demo Virtual Method from Child Class called...");
        }

        public void Show()
        {
            Console.WriteLine("Show something from child");
        }
    }

  sealed class  SubChild : Child
    {
        new public void Show()
        {
            Console.WriteLine("Show something from sub-child");
        }
        public override void DemoVirtual()
        {
            Console.WriteLine("Demo Virtual called from SubChild");
            //parentAge
        }
    }

    class MyString : System.Object
     {
        public override string ToString()
        {

            return "Demo";
            
          
        }
    }

    public class Process
    {
        public Process()
        {
            Console.WriteLine("Process Contstructor Started...");
        }

       ~ Process()
        {

        }
        
    }
    interface IFace
    {
        string DemoMethod()
        {
            return "Hello World";
        }
    }
    static class MyStaticClass
    {
      public  static int age = 100;

        public static void Function()
        {
            Console.WriteLine("Function");
        }


    }

    class DemoStaticCons
    {
       public static int age = 100;

        public int parent_age = 50;
        public DemoStaticCons()
        {
            Console.WriteLine("Intance Constructor called..");
        }
        static DemoStaticCons()
        {
            Console.WriteLine("Static constructor called");
        }

        public static void StaticMethod()
        {
            Console.WriteLine("Static Method called...");
        }
    }


    public class DemoParent
    {
        public void Show()
        {
            Console.WriteLine("Show from DemoParent");
        }
    }
    public class DemoChild : DemoParent
    {
        new public void Show()
        {
            Console.WriteLine("Show from Demo Child");
        }
    }
    //public interface IShape
    //{
    //    // Method
    //    double CalculateArea();

    //    // Property
    //    int NumberOfSides { get; }

    //    // Event
    //    event EventHandler ShapeChanged;

    //    // Indexer
    //    double this[int index] { get; } // Assuming shape has points
    //}


    interface IPerson
    {
        const bool isLiving = true;
        // method
        void PrintFullName();

        // properties
        string Fname { get; set; }

        void OneMoreMethod()
        {
            Console.WriteLine("OneMoreMethod()");
        }
       

    }

    public class Student : IPerson
    {
       
        public string Fname { get ; set ; }

        public void PrintFullName()
        {
            Console.WriteLine("Hi I am Student and My name is Charu !");
        }
    }

    public class Athlete : IPerson
    {
        public string Fname { get ; set ; }

        public void PrintFullName()
        {
            Console.WriteLine("Hi I am Athelete and My name is Rajak !");
        }
    }

    class DemoInterface
    {
       static public IPerson DemoMethod()
        {
            return new Student();

        }
    }


    class Dummy : IPerson
    {
        public string Fname { get; set; }

        public void PrintFullName()
        {
            Console.WriteLine("Dummy for testing purpose ...");
        }
    }








    internal class Program
    {
    [DllImport("user32.dll", CharSet = CharSet.Unicode)]
   static extern IntPtr CreateWindowEx(
int dwExStyle,
string lpClassName,
string lpWindowName,
int dwStyle,
int x,
int y,
int nWidth,
int nHeight,
IntPtr hWndParent,
IntPtr hMenu,
IntPtr hInstance,
IntPtr lpParam);

        static void DemoPerson(IPerson athlete)
        {
            Console.WriteLine("I am DemoPerson Method runnin...");
            athlete.PrintFullName();
        }

        public static double Add(double x, double y)
        {
            return x + y;
        }
        public static int Add(int x, int y)
        {
            return x + y;
        }
        public static int Add(int x, int y, int z)
        {
            return x + y;
        } public int Add(int x, double y, int z)
        {
            return x + z;
        }
        public static int Add(double x, int y, int z)
        {
            return y + z;
        }

        static void DisplayMessage(string message = "default", int repeatCount = 2)
        {
            for (int i = 0; i < repeatCount; i++)
            {
                Console.WriteLine(message);
            }
        }

        static void DisplayTheMessage(int? num1 = 20, int num2 = 10)
        {
            int? result = num1 + num2;

            Console.WriteLine(result);
        }






        interface IBasicChannels
        {
            void BasicChannels();
        }

        interface IIntermediateChannels
        {
            void IntermediateChannels();
        }

        interface IHdChannels
        {
            void HdChannels();
        }



        class Channels : IBasicChannels, IIntermediateChannels, IHdChannels
        {
            public void BasicChannels()
            {
                Console.WriteLine("Basic Channels");
            }

            public void HdChannels()
            {
                Console.WriteLine("Hd Channels");
            }

            public void IntermediateChannels()
            {
                Console.WriteLine("Intermediate Channels");
            }
        }

        public class BasicChannel : IBasicChannels
        {
            public void BasicChannels()
            {
                Console.WriteLine("Basic Channels");
            }
        }

        public class IntermediateChannels : IIntermediateChannels
        {
            void IIntermediateChannels.IntermediateChannels()
            {
                Console.WriteLine("Intemediate Channels");
            }
        }

        public class HdChannels : IHdChannels
        {
            void IHdChannels.HdChannels()
            {

            }
        }

        public class DemoPrivateCons
        {
            private DemoPrivateCons()
            {

            }
            public static DemoPrivateCons GetSingleton
            {
                get { return new DemoPrivateCons(); }

            }

        }

        class Data
        {
            public int MyProperty { get; set; }

            public string MyProperty1 { get; set; }

            public double MyProperty2 { get; set; }
        }

        enum Demo : long
        {
            mon,
            tue
        }


        //<access modifier> <delegate> <return type> <name of delegate><params>

        public delegate int AnyNamedDelegate(int x, int y);

        public delegate int PerformCalculation(int x, int y);


        public static void Calc(int x, int y)
        {


            int result = x + y;
            Console.WriteLine(result);
        }
        public static void Calc1(int x, int y)
        {
            int result = x + y;
            Console.WriteLine(result);
        }

        public static void DemoDelegates(PerformCalculation perf)
        {
            perf.Invoke(100, 100);
        }

        public static PerformCalculation DemoDelegates1()
        {
            return delegate (int x, int y)
            {
                int result = x + y;
                return result;
            };
        }
        public static void Method1TobeReferencedByAnyDelegate(int x, int y)
        {
            int result = x + y;
            Console.WriteLine(result);
        }

        public class Demonstrations
        {
            public int MyProperty3 { get; init; }


            public Demonstrations(string name)
            {
                MyProperty3 = 34;
            }

            static Demonstrations()
            {

            }
            public required int MyProperty { get; set; }

            public int MyProperty1 { get; set; }

            public int MyProperty2 { get; set; }


        }
        public enum MyEnum
        {
            None = 0,
            First,
            Second,
            Third,
            Fourth,
            Fifth,
            Sixth,
            Seventh,
            Eight,
            Nineth,
            Tenth
        }


        public class Node
        {
            public int Data { get; set; }
            public Node Left { get; set; }
            public Node Right { get; set; }

            public Node(int data)
            {
                Data = data;
                Left = null;
                Right = null;

            }
        }
        static void InorderTraversal(Node root)
        {
            if (root != null)
            {
                InorderTraversal(root.Left);
                Console.Write(root.Data + " ");
                InorderTraversal(root.Right);

            }
        }



        public class ListOFDay : IEnumerable<string>
        {
            string[] days = { "Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat" };
            public IEnumerator<string> GetEnumerator()
            {
                foreach (var item in days)
                {
                    yield return item;
                }
            }
            IEnumerator IEnumerable.GetEnumerator()
            {
                return GetEnumerator();
            }
        }













        public class DemoGenericClass<T, M, Y, O, N, D>
        {
            public T FName { get; set; }

            public T LName { get; set; }

            public M mProperty { get; set; }

            Func<T, int> Func { get; set; }
            public T GenericMethod(T x, T y)
            {
                return LName;
            }
        }
        interface I
        {

        }
        //public class DemoGen<T> where T : Person
        //{
        //    public T Value { get; set; }

        //    public T GetVal()
        //    {
        //       // DemoGen<I> demo = new DemoGen<I>();
        //        return Value;
        //    }
        //}



        public class DemoList : IEnumerable<string>
        {
            string[] days = { "Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun" };
            public IEnumerator<string> GetEnumerator()
            {
                foreach (var item in days)
                {
                    yield return item;
                }
            }

            IEnumerator IEnumerable.GetEnumerator()
            {
                return GetEnumerator();
            }

           
        }
        public class Person : IComparable<Person>
        {
            public string Name { get; set; }
            public int Age { get; set; }

            public int CompareTo(Person other)
            {
                return this.Age.CompareTo(other.Age);

            }
        }
        //public class Person 
        //{
        //    public string Name { get; set; }
        //    public int Age { get; set; }
        //}

        class Demo<T>
        {
            private T data;
            public T DemoMethod(T x, T y)
            {
                return data;
            }
        }

        //public interface IDemo<T>
        //{
        //    public T MyProperty { get; set; }
        //    T func();
        //}

        //public class DemoClass : IDemo<int>
        //{
        //    public int MyProperty { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }

        //    public int func()
        //    {

        //    }
        //}




       
        // indexers 

      





        public class MyCollection 
        {
            private int[] items;

            public MyCollection(int size)
            {
                items = new int[size];
            }

            public int this[int index]
            {
                get {  return items[index]; }
                set { items[index] = value; }
            }


        }
        public void FirstOrDefault(Func<string,bool> val)
        {

        }
        public class ParentPerson        {
            public int ParentPersonID { get; set; }
        }

        public class ChildPerson :ParentPerson
        {
            public int x = 100;
            public int ChildPersonID { get; set; }
        }
        public class MyGenClass<T> where T : ParentPerson
        {
           public int x = 10;
            public T MyProperty { get; set; }

            public T DemoVal(T x)
            {

                return x;
            }

        }

        public class People
        {
            public int PersonID { get; set; }

            public string FName { get; set; }

            public string LName { get; set; }

            public string Address { get; set; }
            
            public string Designation { get; set; }
        }
        public interface IDemo<T> 
        {
            T MyFunction(T x,T y);
            public T iPeorperty { get; set; }

            void DemoDefautMethod()
            {

            }
        }
        public class DemoImplementorOfIDemo<T> : IDemo<int>
        {
            public int iPeorperty { get; set; }

            public int MyFunction(int x, int y)
            {
                return 0;
            }
        }
        public class MyDemoIndexersOrArray
        {
            private People[] items;

            public MyDemoIndexersOrArray(int size)
            {
                items = new People[size];
            }
            /// <summary>
            ///          
            /// </summary>
            public int MyProperty { get; set; }


            /// <summary>
            /// This is an Indexer Code 
            /// </summary>
            /// <param name="index"></param>
            /// <returns></returns>
            public People this[int index]
            {
                get { return items[index]; }

                set { items[index] = value; }

            }

        }


        public class Customer
        {
            public int ID { get; set; }

            public string Name { get; set; }
        }

        public class Order
        {
            public int ID { get; set; }

            public int CustomerID { get; set; }

            public string Product { get; set; }


        }

        class Person2 : IDisposable
        {

           public string name;

           public void getName()
            {
                Console.WriteLine("Name: " + name);
            }

            public void Dispose()
            {
                Console.WriteLine("Dispoable called ...");
            }

            // destructor
           
        }
        public class InvalidAgeException : Exception
        {
            public int Prop1 { get; set; }

            public string Prop2 { get; set; }
            public InvalidAgeException(string message) : base(message)
            {

            }
        }

        public class MyCustomExecption : Exception
        {
            public MyCustomExecption(string message):base(message) 
            { 
            
            }
        }

        class Student4 : IDisposable
        {
            private bool disposedValue;

            public int Id { get; set; }
            public int Age { get; set; }
            public string Grade { get; set; }

            public string Name { get; set; }

            protected virtual void Dispose(bool disposing)
            {
                if (!disposedValue)
                {
                    if (disposing)
                    {
                        // TODO: dispose managed state (managed objects)
                    }

                    // TODO: free unmanaged resources (unmanaged objects) and override finalizer
                    // TODO: set large fields to null
                    disposedValue = true;
                }
            }

            // // TODO: override finalizer only if 'Dispose(bool disposing)' has code to free unmanaged resources
            // ~Student4()
            // {
            //     // Do not change this code. Put cleanup code in 'Dispose(bool disposing)' method
            //     Dispose(disposing: false);
            // }

            public void Dispose()
            {
                // Do not change this code. Put cleanup code in 'Dispose(bool disposing)' method
                Dispose(disposing: true);
                GC.SuppressFinalize(this);
            }
        }
        [DllImport("user32.dll", CharSet = CharSet.Unicode)]
        static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);
        static void Main(string[] args)
        {
            int[] data = { 10, 25, 15, 30, 5 };
            int barWidth = 5;
            int maxVal = 30;
            int numRows = 10;
            char barChar = '#';
            char emptyChar = ' ';

            string[] graph = new string[numRows];
            for (int i = 0; i < numRows; i++)
            {
                graph[i] = new string(emptyChar, data.Length * barWidth);
            }

            for (int i = 0; i < data.Length; i++)
            {
                int height = (int)(numRows * (double)data[i] / maxVal);
                for (int j = numRows - 1; j >= numRows - height; j--)
                {
                    graph[j] = graph[j].Substring(0, i * barWidth) +
                              new string(barChar, barWidth) +
                              graph[j].Substring((i + 1) * barWidth);
                }
            }

            foreach (string row in graph)
            {
                Console.WriteLine(row);
            }
            // Create a window using the Win32 API
            IntPtr hWnd = CreateWindowEx(
                0, // Extended window style
                "Edit", // Class name (for a simple edit control)
                "My WinForm in Console App", // Window title
                 1, // Window style (includes visibility)
                100, // X coordinate
                100, // Y coordinate
                400, // Width
                300, // Height
                IntPtr.Zero, // Parent window handle
                IntPtr.Zero, // Menu handle
                IntPtr.Zero, // Instance handle
                IntPtr.Zero // Parameter
            );

            // Show the window
           // ShowWindow(hWnd, 1);

            // Keep the console window open until the user closes it
            //Console.ReadKey();
            //ProductCreator productCreator = new ProductCreator(new ProductA());

            //productCreator.CreateProduct();
            //Products products =   productCreator.GetProducts();

            //Console.WriteLine($"Name :{products.ProductName} | PId : {products.PId} | MRP : {products.MRP}");

            //ProductCreator productCreator1 = new ProductCreator(new ProductB());

            //productCreator1.CreateProduct();
            //Products products1 = productCreator1.GetProducts();

            //Console.WriteLine($"Name :{products1.ProductName} | PId : {products1.PId} | MRP : {products1.MRP}");

            string patternDemo = "([0-9])";
            string pat = "([^0-12$])";

            Regex patternDemo2 = new Regex(@"^(1[0-2]|[1-9])$");
            Regex d2 = new Regex(@"\d");
            Match match=  patternDemo2.Match("12");
           // Console.WriteLine(d2.IsMatch("54"));
            // Console.WriteLine(match.Success);

            Regex regex = new Regex(@"a*");

            string input = "aaaaab";

           // Console.WriteLine(regex.IsMatch(""));

            Regex regex3 = new Regex(@"a{2,4}");
            //string input = "aaaaab";
           
           // Console.WriteLine(regex3.IsMatch("aa"));

            Regex regex1 = new Regex("[0-9]{3}");

          //  Console.WriteLine(regex1.IsMatch("450"));


            string pattern = @"^1[0-2]|[1-9]+(pm|am)$";

            Regex reg5 = new Regex(pattern);

            // Console.WriteLine(reg5.IsMatch("14") + " is match ");

            //string data = @"(?<= ^ [0 - 9] +)\b(am | pm)";

            //Regex reg10 =new Regex(data);

            //Console.WriteLine(reg10.IsMatch("7am")+ " is match");

            // Console.WriteLine(patternDemo2.IsMatch(""));

            // used instead of finally block 
            //using (Student4 stu = new Student4())
            //{

            //}
            //string pattern = "^a..t$";
            //string anyDigit = "\\D";
            //string range = "[1-9].\\D";
            // string clock = "([1-12]^(am|pm)$)";
            //string rangeAlpha = "[a-e]";
            //string clockgem = "([1-12](am|pm))";
            //string demoClock = "\\d(am|pm)";
            //string rangeOfnum = "(^[123456789101112]&(am|pm))";

            //Regex regex = new Regex(rangeOfnum);
            //Console.WriteLine(regex.IsMatch("12pm"));





            //try
            //{
            //    //Console.WriteLine("Give me a number");
            //    //int thatNumber = Convert.ToInt32(Console.ReadLine());
            //    throw new MyCustomExecption("This is not found..."); 


            //}
            //catch (MyCustomExecption ex)
            //{
            //    Console.WriteLine(ex.Message+ " i am My Custom exception..");
            //}
            //catch (Exception ex) /*when (ex.Source != "FirstProgram")*/
            //{
            //    Console.WriteLine(ex.Message+ " I am Exception..");

            //}
            //finally
            //{
            //    Console.WriteLine("Data cleanup the resource.. !");
            //}





            var students = new List<Student4>
             {
             new Student4 { Id =1,Name = "Alice", Age = 20, Grade = "A" },
             new Student4 { Id=2,Name = "Bob", Age = 22, Grade = "B" },
             new Student4 { Id=3,Name = "Charlie", Age = 20, Grade = "A" },
             new Student4 { Id=4,Name = "David", Age = 21, Grade = "B" }
             };

            // // select
            // var listData = students.Select(x => x);

            // // find by ID
            //var studentResult =  students.FirstOrDefault(x => x.Id == 1);

            // // delete by ID
            //students.Remove(studentResult);

            // // update by ID
            // students.Remove(studentResult);
            // Student4 student4 = studentResult;
            // student4.Name = "David";
            // student4.Age = 100;
            // student4.Grade = "M";
            // students.Add(student4);



            // select * from ABC

            //var resultData = students.Select(x => x);

            //foreach (var item in resultData)
            //{
            //    Console.WriteLine(item.Name);
            //}


            //  var firstVal = students.First(x=>x.Age == 100);
            // var firsValDefaul = students.FirstOrDefault(x=>x.Age == 21);




            //Console.WriteLine(firsValDefaul.Name);

            //var all = students.All(x=>x.Age < 100);

            //Console.WriteLine(all);
            //var any = students.Any(x=>x.Age < 100);

            //Console.WriteLine(any);

            //var resultSet = students.Select(x => x);
            //foreach (var item in resultSet)
            //{
            //    Console.WriteLine(item.Grade);
            //}

            var resultofGroup = students.GroupBy(student => student.Age);

            foreach (var group in resultofGroup)
            {
                Console.WriteLine($"Group : {group.Key}");
                foreach (var student in group)
                {

                    Console.WriteLine($"Name : {student.Name} And Age : {student.Age}");
                }


            }


                //            var groupedResult = students.GroupBy(student => student.Grade);

                //            foreach (var group in groupedResult)
                //            {
                //                Console.WriteLine($"Group : {group.Key}");
                //                foreach (var student in group)
                //                {
                //                    Console.WriteLine($"Name : { student.Name}");
                //                }
                //            }

                // Create a large object
                byte[] largeArray = new byte[10000000];

            // Force garbage collection
            GC.Collect();

            // Get the generation of the largeArray object
            int generation = GC.GetGeneration(largeArray);
            Console.WriteLine("Generation: " + generation);

            // Get the total memory used by the managed heap
            long memoryUsed = GC.GetTotalMemory(true);
            Console.WriteLine("Memory used: " + memoryUsed + " bytes");

          
         

            //string pattern1 = "^apple.t$";
            //string pattern2 = "[abc]";
            //string pattern3 = "[a-e]";
            //string pattern4 = "ca*t";
            //Regex regex = new Regex(pattern4);

            //Console.WriteLine(regex.IsMatch("caot"));
            //using(Person2 p = new Person2())
            //{
            //    try
            //    {
            //        throw new InvalidAgeException("Message");
            //    }
            //    catch (Exception ex) when (ex.Source == "FirstProgram")
            //    {

            //        Console.WriteLine("Caught");
            //    }
            //    catch(InvalidAgeException ex)
            //    {
            //        Console.WriteLine("Caught ...");
            //    }

            //}
            //Person2 p1 = new Person2();

            //p1.name = "Ed Sheeran";
            //p1.getName();


            var customers = new List<Customer>
            {
                new Customer { ID = 1, Name = "Alice" },
                new Customer { ID = 2, Name = "Bob" },
                new Customer { ID = 3, Name = "Charlie" },
                 new Customer { ID = 7, Name = "Geeta" },
                new Customer { ID = 8, Name = "Hanah" },
                new Customer { ID = 9, Name = "Irfan" },
                new Customer { ID = 4, Name = "Diana" },
                new Customer { ID = 5, Name = "Elan" },
                new Customer { ID = 6, Name = "Faroq" }
            };


            var orders = new List<Order>
            {
                new Order     { ID = 1, CustomerID = 1, Product = "Jewellery" },
                new Order { ID = 2, CustomerID = 2, Product = "Cosmetics" },
                new Order { ID = 3, CustomerID = 1, Product = "Specs" },
                new Order     { ID = 4, CustomerID = 10, Product = "Jewellery" },
                new Order { ID = 5, CustomerID = 12, Product = "Cosmetics" },
                new Order { ID = 6, CustomerID = 11, Product = "Specs" }
            };


            //var dataResult = from customer in customers
            //                 where customer.ID >= 2    
            //                 orderby customer.ID
            //                 select customer;

            //foreach (var item in dataResult)
            //{
            //    Console.WriteLine($"[{item.ID} || {item.Name}]");
            //}







            //IQueryable < Order > orders1 = orders.AsQueryable();
            //var results =  orders1.Where(x => x.CustomerID > 20);

            //foreach (var item in results)
            //{
            //    Console.WriteLine(item.Product);
            //}




            //var Result = from customer in customers
            //             where customer.ID > 0
            //             orderby customer.Name
            //             select customer;

            //foreach (var item in Result)
            //{
            //    Console.WriteLine(item.Name);
            //}

            var resultofleftOterInnerJoin = from customer in customers
                                            join order in orders on customer.ID equals order.CustomerID into ps_joinTable
                                            from p in ps_joinTable.DefaultIfEmpty()
                                            select new { customer.Name, ProductName = p == null ? "(No product) " : p.Product};

            var resultofrightOterInnerJoin = from order in orders
                                             join customer in customers on order.CustomerID equals customer.ID into ps_joinTable
                                             from p in ps_joinTable.DefaultIfEmpty()
                                             select new { CustomerName = p == null ? "(No Customer) " : p.Name, order.Product };

            //var resultofJoin = from customer in customers
            //                   join order in orders on customer.ID equals order.ID into temp
            //                   from t in temp.DefaultIfEmpty()
            //                   select new { customer.Name, Product = t == null ? "(no val)" : t.Product };

            //foreach (var item in resultofJoin)
            //{
            //    Console.WriteLine($"{item.Name} - {item.Product}");
            //}
            //Console.WriteLine("-----------------------------------");

            //var resultofRightOuterJoin = from order in orders
            //                             join customer in customers on order.CustomerID equals customer.ID into ps_joinTable1
            //                             from p in ps_joinTable1.DefaultIfEmpty()
            //                             select new { order.Product, CustomerName = p == null ? "(No Name) " : p.Name };

            //foreach (var item in resultofrightOterInnerJoin)
            //{
            //    Console.WriteLine($"[The customer :{item.CustomerName} bought {item.Product}");
            //}
            //Console.WriteLine("-----------------------------------------------------------");
            //foreach (var item in resultofleftOterInnerJoin)
            //{
            //    Console.WriteLine($"[The customer :{item.Name} bought {item.ProductName}");
            //}


            //var innerJoinResult = from outer in customers
            //                      join inner in orders on outer.ID equals inner.ID
            //                      select new { outer.Name, inner.Product };


            //foreach (var item in innerJoinResult)
            //{
            //    Console.WriteLine($"{item.Name} and {item.Product}");
            //}



            //DrawShapeA drawShapeA = new DrawShapeA();

            //IShape1 shapeA=   drawShapeA.GetShape();
            //IColor colorA= drawShapeA.GetColor();

            //shapeA.Draw();
            //colorA.Fill();

            //DrawShapeB drawShapeB = new DrawShapeB();   
            //IShape1 shapeB= drawShapeB.GetShape();
            //IColor colorB= drawShapeB.GetColor();

            //shapeB.Draw();
            //colorB.Fill();



            //SingleTonDemo singleton = SingleTonDemo.GetInstance;

            //Singleton1 refere = Singleton1.Instance;

            //Singleton1 refere1 = Singleton1.Instance;

            //Singleton1 refere2 = Singleton1.Instance;

            //Console.WriteLine("SingleTon");
            //Console.WriteLine(refere.SingletonReturn());

            //Console.WriteLine(refere1.SingletonReturn());

            //Console.WriteLine(refere2.SingletonReturn());





            //NonSingleton nonSingleton = new NonSingleton();

            //NonSingleton nonSingleton2 = new NonSingleton();

            //NonSingleton nonSingleton3 = new NonSingleton();


            //Console.WriteLine("NonSingleTon");
            //Console.WriteLine(nonSingleton.SingletonReturn());

            //Console.WriteLine(nonSingleton2.SingletonReturn());

            //Console.WriteLine(nonSingleton3.SingletonReturn());





            //Factory factory = new Factory();

            //IDocument doc = factory.GetMeTheDocument("word");
            //doc.GetDocument();

            //IDocument doc2 = factory.GetMeTheDocument("pdf");
            //doc2.GetDocument();





            // Singleton



            // List<int> list = new List<int>();


            //MyDemoIndexersOrArray arrays = new MyDemoIndexersOrArray(20);
            //arrays[0] = new People()
            //{
            //    LName = "One",
            //    FName = "Two",
            //    Address = "Pune",
            //    Designation = "HR",
            //    PersonID = 1
            //};


            //Predicate<int> predicate1 = x =>  x > 10;



            //Console.WriteLine(arrays[0]);


            //List<People> listofPeople = new List<People>();



            //for (int i = 1; i < 10; i++)
            //{
            //    People people = new People();
            //    people.PersonID = i;
            //    people.FName = "FName"+i.ToString();
            //    people.LName = "LName" + i.ToString();
            //    people.Address = "Pune" + i.ToString();
            //    people.Designation = "HR" + i.ToString();
            //    listofPeople.Add(people);
            //}


            //foreach (var item in listofPeople)
            //{
            //    Console.WriteLine($"[{item.PersonID}] {item.FName} |{item.LName} | {item.Designation} | {item.Address}]");
            //}

            //People result = listofPeople.FirstOrDefault(x => x.PersonID == 9);
            //Console.WriteLine();
            //Console.WriteLine();
            //Console.WriteLine("[Your seareched for ProductID = 9 and below is the result]");
            //Console.WriteLine($"[{result.PersonID}] {result.FName} | {result.LName} | {result.Designation} |{result.Address}");


            // MyGenClass<ChildPerson> perSon = new MyGenClass<ChildPerson>();
            // ChildPerson childPerson = new ChildPerson();

            // childPerson.x =100; 
            //var result =    perSon.DemoVal(childPerson);

            // Console.WriteLine(result.x);



        }  

          
        

             
           
           
              
          
            
         



      

                 
            
                
            //DemoGenericClass<string, int, int, int, int, int> genericClass = 
            //    new DemoGenericClass<string, int, int, int, int, int>();

            


            //MyCollection list = new MyCollection(10);
           

            //Predicate<int> predicate = x => x > 2;
            //Console.WriteLine(predicate(1));
            //Console.WriteLine(predicate(10));




            //Func<int,string, double,decimal, int> func1 = (a, x, y, z) =>
            //{
            //    return 100;
            //};

            // Console.WriteLine(func1(12,"demo",23.45,23.56m));

            //Func<int, string, int> func = (x, y) =>
            //{
            //    Console.WriteLine(x);
            //    Console.WriteLine(y);
            //    return 34;
            //};

            //Action<string, string, int, decimal> action = (x, y, z, a) =>
            //{
            //    Console.WriteLine(x);
            //};

            //List<string> demo = new List<string>();
            //demo.FirstOrDefault(x => x.Contains("23"));

            
            //Func<string, bool> func2 = x => x.Contains("demo");


            //Action<int, string> action = (x, y) =>
            //{
            //    Console.WriteLine(x);
            //    Console.WriteLine(y);
            //};

            //action(100, "string");

          //  Console.WriteLine(func(1,"demo"));    

            //Predicate<int> res = x => x > 0;

            //Console.WriteLine(res(100));

            //ListOFDay days = new ListOFDay();
            //Node node = new Node(23);

            //foreach (var item in days)
            //{
            //    Console.WriteLine(item);
            //}

            //DemoList list = new DemoList();

            //foreach (var item in list)
            //{
            //    Console.WriteLine(item);
            //}

            //LinkedList<string> ints = new LinkedList<string>();

            //ints.AddFirst("First");

            //ints.AddLast("Second");

            //ints.AddLast("Third");

            //ints.AddFirst("Second First");

            //ints.AddFirst("Third First");

            //ints.AddLast("Fourth");

            //ints.AddLast("Fifth");

            ////LinkedListNode<string> node = ints.Find("Fourth");

            //LinkedListNode<string> node = ints.Find("Fourth");

            //ints.AddBefore(node, "Cheese");



            //foreach (var item in ints)
            //{
            //    Console.WriteLine(item);
            //}




            //foreach (var item in ints)
            //{
            //    Console.WriteLine(item);
            //}


            //Queue<int> queue = new Queue<int>();

            //queue.Enqueue(1);

            //queue.Enqueue(2);
            //queue.Enqueue(3);
            //queue.Enqueue(4);

            //foreach (var item in queue)
            //{
            //    Console.WriteLine(item);
            //}

            //queue.Dequeue();

            //foreach (var item in queue)
            //{
            //    Console.WriteLine(item);
            //}

            //queue.Clear();





            //Stack<int> stack = new Stack<int>();


            //stack.Push(1);
            //stack.Push(2);
            //stack.Push(3);
            //stack.Push(4);

            //foreach (var item in stack)
            //{
            //    Console.WriteLine(item);
            //}

            //stack.Pop();
            //foreach (var item in stack)
            //{
            //    Console.WriteLine(item);
            //}

            // Console.WriteLine(stack.Peek());

            //while (stack.Count > 0)
            //{
            //    stack.Pop();
            //};

            //stack.Clear();

            //foreach (var item in stack)
            //{
            //    Console.WriteLine(item);
            //}


            // create
            //Dictionary<int, string> dictionary = new Dictionary<int, string>();

            //dictionary.Add(0, "Sun");
            //dictionary.Add(1, "Mon");
            //dictionary.Add(2, "Tue");
            //dictionary.Add(3, "Wen");
            //dictionary.Add(4, "Thu");
            //dictionary.Add(5, "Fri");
            //dictionary.Add(6, "Sat");

            //dictionary.TryAdd(6, "Sat");

            //foreach (var item in dictionary.Values)
            //{
            //    Console.WriteLine(item);
            //}



            //Hashtable days = new Hashtable();

            //days.Add(0, "Sun");
            //days.Add(1, "Mon");
            //days.Add(2, "Tue");
            //days.Add(3, "Wed");
            //days.Add(4, "Thu");
            //days.Add(5, "Fri");
            //days.Add(6, "Sat");

            //for (int i = 0; i < days.Count; i++)
            //{
            //    Console.WriteLine(days[i]);
            //}


            // create
            // Hashtable hashtable = new Hashtable();
            // hashtable.Add("id", 100);
            // hashtable.Add("fname", "Rajesh");
            // hashtable.Add("lname", "Gogia");
            // hashtable.Add("age", 26);
            // hashtable.Add("mname", "Gogia");

            //// hashtable.Add("id", 200);

            // // deletion
            //// hashtable.Remove("id"); 


            // if (hashtable.ContainsKey("id"))
            // {

            //     Console.WriteLine("id is not available");
            // }
            // else
            // {
            //     // updation
            //     hashtable.Remove("id");                
            //     hashtable.Add("id", 23);
            // }

            // // retrieve
            //Console.WriteLine(hashtable["age"]);

            //foreach (var item in hashtable.Values)
            //{
            //    Console.WriteLine(item);
            //}



            // creation
            //ArrayList arrayList = new ArrayList();
            //arrayList.Add(1);
            //arrayList.Add('C');
            //arrayList.Add("some value");
            //arrayList.Add(23.56);


            // retrieval
            //foreach (var item in arrayList)
            //{
            //    Console.WriteLine(item);
            //}

            // indexer
            //  Console.WriteLine(arrayList[2]);

            //for (int i = 0; i < arrayList.Count; i++)
            //{
            //    Console.WriteLine(arrayList[i]);
            //}

            //// updation
            //arrayList[2] = "It is not more some value it is now this string";

            //// deletion
            ////arrayList.Remove('C');
















            //Hashtable myHash = new Hashtable();
            //myHash.Add("age", 40);
            //myHash.Add("name", "Reeta");

            //Console.WriteLine(myHash["age"]);

            //Dictionary<int,string> keyValuePairs = new Dictionary<int,string>();

            //keyValuePairs.Add(1, "abc");
            //keyValuePairs.Add(2, "def");

            //foreach (var item in keyValuePairs)
            //{
            //    Console.WriteLine(item.Value);
            //}






            //           LinkedList<string>
            //groceryList = new LinkedList<string>();

            //           groceryList.AddLast("Milk");
            //           groceryList.AddLast("Bread");
            //           groceryList.AddFirst("Eggs");

            //           // Iterate through the list
            //           foreach (string item in groceryList)
            //           {
            //               Console.WriteLine(item);
            //           }

            //           // Remove an item
            //           groceryList.Remove("Bread");

            //           // Insert an item at a specific position
            //           LinkedListNode<string> node = groceryList.Find("Milk");
            //           groceryList.AddAfter(node, "Cheese");

            //           Console.WriteLine("\nUpdated list:");
            //           foreach (string item in groceryList)
            //           {
            //               Console.WriteLine(item);
            //           }











            //Node root = new Node(5);

            //root.Left = new Node(3);
            //root.Right = new Node(7);
            //root.Left.Left = new Node(1);
            //root.Left.Right = new Node(4);


            //InorderTraversal(root);


            //// Traverse the tree (e.g., Inorder traversal)
            //InorderTraversal(root);

            // List<Product> products = new List<Product>
            // {
            //     new Product { Name = "Product A", Price = 10.99m },
            //     new Product { Name = "Product B", Price = 19.99m },
            //     new Product { Name = "Product C", Price = 5.99m }
            // };

            //// Sort by price ascending
            // products.Sort(new ProductPriceComparer(true));
            // Console.WriteLine("ascending order");
            // foreach (var item in products)
            // {
            //     Console.WriteLine($"{item.Name}: {item.Price}");
            // }
            // // Sort by price descending
            // products.Sort(new ProductPriceComparer(false));
            // Console.WriteLine("descending order");
            // foreach (var item in products)
            // {
            //     Console.WriteLine($"{item.Name}: {item.Price}");
            // }


            //List<Person> people = new List<Person>
            //       {
            //           new Person { Name = "alice", Age = 30 },
            //           new Person { Name = "bob", Age = 25 },
            //           new Person { Name = "charlie",
            //Age = 35 }
            //       };

            //people.Sort(); // sorts by age using the implemented compareto method

            //foreach (var person in people)
            //{
            //    Console.WriteLine($"{person.Name}: {person.Age}");
            //}











            //IterationOFDays days = new IterationOFDays();

            //foreach (var item in days)
            //{
            //    Console.WriteLine(item);
            //}

            // Console.WriteLine(Convert.ToUInt32(MyEnum.Second));
            // Console.WriteLine(MyEnum.Fourth);

            // Demonstrations demons = new Demonstrations("DemoName")
            // {
            //     MyProperty = 67
            //                };

            //if (Convert.ToInt32(MyEnum.Fourth) ==  4)
            // {

            // }

            // tuples 
            //var t = (1, 'C', 23.45f, 222.444m, 34.67, 60000, 34, 8,"string value", 9, 10);

            //Console.WriteLine(t.Item2);

            //t.Item2 = 'A';

            // destructuring of tupple
            //var tupple = ("post offfice", 567);

            //var (office,size) = tupple;

            //Console.WriteLine(office);

            //Console.WriteLine(size);



            // Console.WriteLine(t.Item2);


            //(int max,int min) FindMaxorMin(int value)
            //{
            //    return (100,100);
            //}


            //var tu = FindMaxorMin(12);

            //Console.WriteLine(tu.min);
            //Console.WriteLine(tu.max);


            //(double Sum, int Count) t2 = (4.5, 3);

            //Console.WriteLine($"Sum of {t2.Count} elements is {t2.Sum}.");


            //const double pi = 3.14;

            //var anonArray = new[] { new { name = "apple", diam = 4 }, new { name = "grape", diam = 1 } };

            //foreach (var item in anonArray)
            //{
            //    Console.WriteLine(item.name);
            //    Console.WriteLine(item.diam);
            //}

            //PerformCalculation performCalculation = Calc;
            //performCalculation += Calc1;

            ////performCalculation(100, 100);

            //DemoDelegates(performCalculation);         

            //PerformCalculation perf = DemoDelegates1();


            // normal method
            // AnyNamedDelegate referer = Method1TobeReferencedByAnyDelegate;


            // anonymous methods
            //referer = delegate (int x, int y)
            //{
            //    int result = x + y;
            //    Console.WriteLine(result);
            //};

            // lambdas expression
            //AnyNamedDelegate referer = (x, y) =>
            //{

            //    return x + y;
            //};

            //var anomymousType = new { name = "Some name", age = 78 };

            //Console.WriteLine(anomymousType.age);
            //Console.WriteLine(anomymousType.name);




            //  referer(200, 200);





            // referer.Invoke(100, 100);

            //PerformCalculation  perf = delegate (int x, int y)
            //{
            //    return x + y;
            //};

            //perf = (x, y) => x + y;


            //perf.Invoke(50, 100);













            // int[] demos = { 1, 1, 1, 1, };


            // string data = "TheCountofmycharrachtersis28";

            //Console.WriteLine(data.WordCount());
            //DemoMethods demoMethods = new DemoMethods();
            //demoMethods.DemoMethodFour();


            //Console.WriteLine(Demo.mon);

            //Console.BackgroundColor = ConsoleColor.Blue;
            //Console.ForegroundColor = ConsoleColor.Red;
            //Console.Clear();
            //while (true)
            //{
            //    Console.WriteLine("Kindly select the option from the list below :");
            //    Console.WriteLine("Press 0 for creating new Entry");
            //    Console.WriteLine("Press 1 for deleting an Entry");
            //    Console.WriteLine("Press 2 for updating an Entry");
            //    Console.WriteLine("Press 3 for listing all the Entries");

            //    int switch_Choice = Convert.ToInt32(Console.ReadLine());
            //    DataManagement management = new DataManagement();   

            //    switch (switch_Choice)
            //    {
            //        case 0:
            //           // Console.WriteLine("You selected option 0");
            //            management.CreateData();
            //            break;
            //        case 1:
            //            Console.WriteLine("You selected option 1");
            //            break;
            //        case 2:
            //            Console.WriteLine("You selected option 2");
            //            break;
            //        case 3:
            //            Console.WriteLine("You selected option 3");
            //            break;

            //        default:
            //            break;
            //    }
            //}



            //Data data = new Data();
            //data.MyProperty1 = "";
            //data.MyProperty = 23;
            //data.MyProperty2 = 34.56;
            //Data[] datas = new Data[23];

            //IHdChannels[] hdChannels = new IHdChannels[23];

            //hdChannels[0] = new HdChannels();



            //datas[0] = data;




            //DemoPrivateCons con = DemoPrivateCons.GetSingleton;


            //IHdChannels channels = new Channels();

            //channels.HdChannels();

            //IIntermediateChannels intermediateChannels = new Channels();

            //intermediateChannels.IntermediateChannels();


            //IBasicChannels basicChannels = new Channels();

            //basicChannels.BasicChannels();


            //if (basicChannels is Channels)
            //{
            //    Console.WriteLine(true);
            //}
            //else
            //{
            //    Console.WriteLine(false);
            //}





            //DisplayTheMessage("My name is LorumIpsum");

            //IPerson referencer =   DemoInterface.DemoMethod(); 

            //referencer.PrintFullName(); 

            //DisplayTheMessage();
            ////DemoPerson(new Student());
            ////DemoPerson(new Athlete());

            //DemoPerson(new Dummy());
            //IPerson person = new Dummy();

            //person.OneMoreMethod();


            // Console.WriteLine(Program.Add(123.45, 2345.89));
            // DisplayMessage(repeatCount: 10, message: "hello world");
            //DemoParent parent = new DemoParent();
            //parent.Show();
            //DemoParent demoParent = new DemoChild();
            //demoParent.Show();  

            //string isImuttable = "DEMO";

            //StringBuilder sb = new StringBuilder("Demo ");

            //SubChild subChild = new SubChild();
            //subChild.Show();

            //Child chd = new SubChild();
            //chd.Show();


            //for (int i = 0; i < 1000000; i++)
            //{

            //sb.AppendLine("Line appended");

            //Console.WriteLine(sb.ToString());

            // }

            // string val = isImuttable.Split(',')[0];

            //Console.WriteLine(isImuttable.First(x => x == 'd'));

            //string[] days = { "Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun" };



            //foreach (var item in days)
            //{
            //    Console.WriteLine(item);
            //} 



            //Console.WriteLine(isImuttable.ToCharArray());

            //foreach (var item in isImuttable.ToCharArray())
            //{
            //    Console.Write(item);
            //}

            //foreach (var item in isImuttable.Split(' '))
            //{
            //    Console.WriteLine($"{item}");
            //}


            //StringBuilder sb  = new StringBuilder("Demo ");
            //sb.AppendLine("Line appended");

            //Console.WriteLine(sb.ToString());   



            // Mathematics math = new Mathematics();   
            // int[] arr = null;

            // int? reultatZeroPlace = arr?[0];
            // int? x = 50;

            //Console.WriteLine(math.Add(x ??= 10, 50));



            //TechnicalScripter tc = new TechnicalScripter("Pythagoras Theram",100);

            //Console.WriteLine(tc.Data);

            //TechnicalScripter tcCopyc = new TechnicalScripter(tc);

            //Console.WriteLine(tcCopyc.Data);

            //Console.WriteLine(DemoStaticCons.age);

            //DemoStaticCons.StaticMethod();

            //Console.WriteLine(DemoStaticCons.age);

            //DemoStaticCons demoStaticCons = new DemoStaticCons();

            //demoStaticCons.parent_age = 75;

            //DemoStaticCons demoStaticCons1 = new DemoStaticCons();

            //DemoStaticCons demoStaticCons2 = new DemoStaticCons();


            // SubChild sub_child = new SubChild();
            // Console.WriteLine(sub_child.parentAge);





            //Person2 person1 = new Person2 { Age = 30, Name = "Alice", Address = new Address1 { Street = "123 Main St", City = "Anytown" } };
            //Person2 person2 = person1.DeepCopy();

            //person2.Name = "Bob";
            //person2.Address.Street = "456 Elm St";

            //Console.WriteLine(person1.Name); // Output: Alice
            //Console.WriteLine(person1.Address.Street); // Output: 123 Main St

            //TechnicalScripter technicalScripter = new TechnicalScripter("Pythagoras Theoram",100);

            //TechnicalScripter t2 = new TechnicalScripter(technicalScripter);
            //Console.WriteLine(t2.Data);

            //Person1 person1 = new Person1 { Age = 30, Name = "Alice", Address = new Address1 { Street = "123 Main St", City = "Anytown" } };
            //Person1 person2 = person1; // Shallow copy

            //person2.Name = "Bob";
            //person2.Address.Street = "456 Elm St";

            //Console.WriteLine(person1.Name); // Output: Bob
            //Console.WriteLine(person1.Address.Street); // Output: 456 Elm St


            //  int? count = null;
            //  count = 10; // count will be 10

            //  Mathematics mathematics = new Mathematics();
            //  int? a = null;

            //Console.WriteLine(mathematics.Add(a ??= 12, 20));

            //Console.WriteLine(count);


            //int?[] arrays = null;

            //int? firstVal = arrays[0];

            //Mathematics maths = null;

            //var result = maths?.name;

            //Console.WriteLine(firstVal.ToString()); 


            //Console.WriteLine(MyClass.a);
            //MyClass st = new MyClass();
            //MyClass st1= new MyClass();
            //Console.WriteLine(st1.d);

            //Person p = new Person("Daniel", 50);
            //p.DisplayNameAndAge();
            //Console.WriteLine($"{p.Name} : Name");
            //Console.WriteLine($"{p.Age} : Age");
            //p.Name = "Danielle";
            //p.Age = 78;
            //Console.WriteLine($"{p.Name} : Name");
            //Console.WriteLine($"{p.Age} : Age");



            //int a = 10;
            //int b = 15;
            //Console.WriteLine($"Before Swap a:{a} and b :{b}");
            //Mathematics.Swap(ref a, ref b);
            //Console.WriteLine($"After Swap a:{a} and b :{b}");

            //bool val =   Mathematics.TryParseInt("123",out var result);
            //Console.WriteLine($" resultFromTryParse:{val} and Other returned value is :{result}");

            //string val = "demo";
            //int result = 0;

            //  bool isitorNotcovertable =  int.TryParse(val, out  result);




            //Console.WriteLine($"is it convertible: {isitorNotcovertable} and value of out result is: {result}");

            // Convert.ToInt32(val);   

            // Ex : Use loops to generate number whereby the max range is given by user
            //      to find out even numbers and odd numbers ( print those)
            //      Re-do these with arrays

            //string name=null;
            //int age = 100;
            //string message = name ?? "Unknown";
            //Console.WriteLine(message);

            // short hand for if else 

            //string result = name is null ? "yes" : "no";

            //string resultNumeric = age < 50 ? "yes" : "no";

            //Console.WriteLine(result+ " name is numm");

            //Console.WriteLine(resultNumeric+" age < 50");


            //Mathematics maths = new Mathematics();

            //if(maths is Mathematics)
            //{
            //    Console.WriteLine("yes");
            //}
            //else
            //{
            //    Console.WriteLine("No");
            //}
            //if (23 is int)
            //{
            //    Console.WriteLine(  "yes");
            //}
            //else
            //{
            //    Console.WriteLine("no"); 
            //}

            //Console.WriteLine(result);
            //int size = 10;
            //Console.WriteLine("Please enter youe age ");
            //size = Convert.ToInt32(Console.ReadLine());            

            //switch (size)
            //{
            //    case 15:
            //        Console.WriteLine("Hello Your age is 15 years");
            //        break;
            //        case 20:
            //        Console.WriteLine("Hello Your age is 20 years");
            //        break;
            //    default:
            //        Console.WriteLine("You are not eligible");
            //        break;
            //}
            //int a = 10;
            //int ctr = 0;
            //do
            //{
            //    Console.WriteLine(ctr);
            //    ctr++;
            //} while ( ctr > a);





            //int a = 10, b = 20;
            //Mathematics.Swap(a, b);
            //Console.WriteLine("a = " + a); // Output: 20
            //Console.WriteLine("b = " + b); // Output: 10

            //string input = "123";
            //int number;
            //if (Mathematics.TryParseInt(input, out number))
            //{
            //    Console.WriteLine("Parsed number: " + number);
            //}
            //else
            //{
            //    Console.WriteLine("Invalid input");
            //}

            // Findout the Even and Odd number if the number is taken from
            // user 


            //int num = 10;
            //object obj = num; // Boxing: int to object
            //Console.WriteLine(obj);
            //int num2 = (int)obj; // Unboxing: object to int
            //Console.WriteLine(num2);

            //int a = 100, b = 100;
            //bool isGreater = a > b; // Greater than
            //Console.WriteLine(a + ">" + b + " : isGreater :" + isGreater);

            //bool isLess = a < b; // Less than
            //Console.WriteLine(a + "<" + b + " : isLess :" + isLess);

            //bool isEqual = a == b; // Equal to
            //Console.WriteLine(a + "==" + b + " : isEqual :" + isEqual);

            //bool isNotEqual = a != b; // Not equal to
            //Console.WriteLine(a + "!=" + b + " : isNotEqual :" + isNotEqual);

            // bool x = true, y = false;
            //bool andResult = x && y; // Logical AND
            //Console.WriteLine(andResult);

            //bool orResult = x || y; // Logical OR
            //Console.WriteLine(orResult);

            //bool notResult = !x; // Logical NOT
            //Console.WriteLine(notResult);


            //if (!y)
            //{
            //    Console.WriteLine("All true");
            //}
            //else
            //{
            //    Console.WriteLine("All not true");
            //}


            //int a = 10, b = 5;
            //int sum = a + b; // Addition
            //Console.WriteLine(sum);
            //int difference = a - b; // Subtraction
            //Console.WriteLine(difference);
            //int product = a * b; // Multiplication
            //Console.WriteLine(product);



            //int quotient = a / b; // Division
            //Console.WriteLine(quotient);
            //int remainder = a % b; // Modulus
            //Console.WriteLine(remainder);

            //Console.WriteLine(Math.Pow(10, 4));



            //int[] ints = new int[10];
            //ints[0] = 89;

            // int[] ints2 = { 1, 2, 3, 4, 5, 6 };

            //var int1 = 78;
            //var int2 = 100;
            //var int3 = int1 + int2;

            //dynamic demo = 67;

            //demo.DoSomething();

            //foreach (var item in ints2)
            //{
            //    Console.WriteLine(item);
            //}


            //foreach (var item in ints2)
            //{
            //    Console.WriteLine(item);
            //}



            //int[,] matrix = new int[2,2];

            //int[,] matrix2 = { 
            //    {1,2 }, 

            //    {3,4 } 
            //};            


            //matrix[0,0] = 1;
            //matrix[0,1] = 2;
            //matrix[1,0] = 3;
            //matrix[1,1] = 4;


            //int[,,] matrix3d = new int[2,2,2];

            //matrix3d[0,0, 0] = 1;
            //matrix3d[0,0, 1] = 2;
            //matrix3d[1,1, 0] = 3;
            //matrix3d[2,1, 1] = 4;



            //int[,,] matrix = new int[2, 2, 3]; // 2 rows, 3 columns
            //matrix[0,0, 0] = 1;
            //matrix[1, 1, 2] = 9;

            //int[][] jaggedArray = new int[3][];
            //jaggedArray[0] = new int[2];
            //jaggedArray[1] = new int[3];
            //jaggedArray[2] = new int[1];

            //jaggedArray[0][1] = 0;
            //jaggedArray[1][1] = 23;
            //jaggedArray[2][1] = 0;


            ////string val = "values";
            //string? val2 = null;

            //int? val3 = null;

            //double? val4 = null;    
            


            //Console.WriteLine(val4); 
            

            //string? name = "default";
            //Console.WriteLine("Please enter your name .");           
            //name = Console.ReadLine();
            //Console.WriteLine("Hello, World to "+name+" !");
            //while (true)
            //{
            //    Mathematics maths = new Mathematics();
            //    //Console.WriteLine("Please enter first Number");
            //    maths.WriteToScreenFN();
            //    int num1 = Convert.ToInt32(Console.ReadLine());
            //    //Console.WriteLine("Please enter second number");
            //    maths.WriteToScreenSN();
            //    int num2 = Convert.ToInt32(Console.ReadLine());


            //    int multiplication = maths.Add(num1, num2);

            //    Console.WriteLine("The multiplication result is : " + multiplication);
            //}




        }

    internal class Customer
    {
    }
}
    class PersonalDetails
    {
        public PersonalDetails()
        {

        }
        public string Name { get; set; }
        public int Id { get; set; }
        public string FirstName { get; set; }
        = "default";
        public string LastName { get; set; }
        = "default";
        
    }
