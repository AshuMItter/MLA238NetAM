﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FirstProgram
{
    
    public interface IShape
    {
        void Draw();
    }

    public class Square : IShape
    {
        public void Draw()
        {
            Console.WriteLine("Drawing a square");
        }
    }

    public class Circle : IShape
    {
        public void Draw()
        {
            Console.WriteLine("Drawing a circle");
        }
    }

    public class ShapeFactory
    {
        public static IShape CreateShape(ShapeType type)
        {
            switch (type)
            {
                case ShapeType.Square:
                    return new Square();
                case ShapeType.Circle:
                    return new Circle();
                default:
                    throw new ArgumentException("Invalid shape type");
            }
        }
    }

    public enum ShapeType
    {
        Square,
        Circle
    }

    //public class Client
    //{
    //    public static void Main(string[] args)
    //    {
    //        IShape square = ShapeFactory.CreateShape(ShapeType.Square);
    //        square.Draw(); // Output: Drawing a square

    //        IShape circle = ShapeFactory.CreateShape(ShapeType.Circle);
    //        circle.Draw(); // Output: Drawing a circle
    //    }
    //}

}
//benefits
//Benefits:

//Decouples client code from concrete product creation.
//Enables easy switching between products without modifying client code.