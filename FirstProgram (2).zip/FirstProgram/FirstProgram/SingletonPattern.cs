﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FirstProgram
{



    public class SingleTonDemo
    {
        public int x = 0;

        public static SingleTonDemo GetInstance { get {
                return new SingleTonDemo();
            } }
        public int Increment() {             
            return x++;        
        }
        private SingleTonDemo() { 
        
        }
    }












    public class NonSingleton
    {
        int x = 0;
        public int SingletonReturn()
        {
            return x++;
        }
    }
    
    public sealed class Singleton1
    {
      // let a = new Array[1:'','','']

        int x = 0;
        public int SingletonReturn()
        {
           return x++;
        }
        private Singleton1() { }
        private static Singleton1 instance = null;
        public static Singleton1 Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new Singleton1();
                }
                return instance;
            }
        }
    }
}
