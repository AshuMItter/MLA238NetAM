﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FirstProgram
{

    public class Product
    {
        public string Name { get; set; }
        public decimal Price { get; set; }
    }

public class ProductPriceComparer : IComparer<Product>
{
    private readonly bool _ascending;

    public ProductPriceComparer(bool ascending)
    {
        _ascending = ascending;
    }

    public int Compare(Product x, Product y)
    {
        if (x == null || y == null)
        {
            throw new ArgumentNullException();
        }

        return _ascending ? x.Price.CompareTo(y.Price) : y.Name.CompareTo(x.Name);
    }
}



    internal class TwentyDayCSharp
    {
    }
    class IterationOFDays : IEnumerable<string>
    {
        string[] days = { "Mon", "Tue", "Wed", "Thu", "Fri", "Sat","Sun" };
        public IEnumerator<string> GetEnumerator()
        {
            foreach (var item in days)
            {
                yield return item;
            }
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }
    }
}
