﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FirstProgram
{
    // i want to watch a movie

    public class Projector
    {
       public void ProjectMovie()
        {
            Console.WriteLine("Projecting the movie");
        }
    }

    public class WhiteScreen
    {
        public void RaiseWhiteScreen()
        {
            Console.WriteLine("White Screen Raised ..");
        }
        public void DownTheWhiteScreen()
        {
            Console.WriteLine("White Screen shut ..");
        }

    }

    public class Electricity
    {
        public void ElecytricityIn()
        {
            Console.WriteLine("Electricity on...");
        }
        public void ElecytricityOut()
        {
            Console.WriteLine("Electricity off...");
        }
    }

    public class Wires
    {
        public void WiresIn()
        {
            Console.WriteLine("Wires connected...");
        }
        public void WiresOut()
        {
            Console.WriteLine("Wires disconnected...");
        }
    }

    public class MovieOrPicture
    {
        public void Movie()
        {
            Console.WriteLine("DDLJ");
        }
    }

    public class Facade
    {
        private MovieOrPicture movie;
        private Electricity electricity;
        private Wires wires;
        private Projector projector;
        private WhiteScreen whiteScreen;

        public Facade()
        {
            movie = new MovieOrPicture();
            electricity = new Electricity();    
            wires = new Wires();
            projector = new Projector();    
            whiteScreen = new WhiteScreen();    
        }
        public void StartTheMovie()
        {
            movie.Movie();
            Thread.Sleep(2000);
            Console.WriteLine("Movie Started...");
            Thread.Sleep(2000);           
            electricity.ElecytricityIn();
            Thread.Sleep(2000);
            wires.WiresIn();
            Thread.Sleep(2000);
            whiteScreen.RaiseWhiteScreen();
            Thread.Sleep(2000);
            projector.ProjectMovie();
            Thread.Sleep(2000);
           


        }
        public void CloseTheMovie()
        {
          

            Console.WriteLine("Ended watching the movie");
            movie.Movie();
            Thread.Sleep(2000);
            Console.WriteLine("Projection Stalled");
            Thread.Sleep(2000);
            whiteScreen.DownTheWhiteScreen();
            Thread.Sleep(2000);
            electricity.ElecytricityOut();
            Thread.Sleep(2000);
            wires.WiresOut();
            Thread.Sleep(2000);
           
            Console.WriteLine("Movie Ends...");
        }
    }

    internal class FacadeSctructuralPattern
    {
    }
}
