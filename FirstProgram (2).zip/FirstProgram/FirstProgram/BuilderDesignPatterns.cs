﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FirstProgram
{
   public interface IProductBuilder
    {
        void SetPid();
        void SetProductName();
        void SetMRP();
        Products GetProducts();
    }
    public class Products
    {
        public int PId { get; set; }

        public string ProductName { get; set; }

        public decimal MRP { get; set; }

    }

    public class ProductB : IProductBuilder
    {
        Products products = new Products();
        public Products GetProducts()
        {
            return products;    
        }

        public void SetMRP()
        {
            products.MRP = 300;
        }

        public void SetPid()
        {
            products.PId = 102;
        }

        public void SetProductName()
        {
            products.ProductName = "HnM Denims";
        }
    }
    

    

    public class ProductA : IProductBuilder
    {
        Products products = new Products();
        public Products GetProducts()
        {
            return products;
        }

        public void SetMRP()
        {
            products.MRP = 200;
        }

        public void SetPid()
        {
            products.PId = 101;
        }

        public void SetProductName()
        {
            products.ProductName = "RS Aggarwal Book";
        }
    }

    public class ProductCreator
    {
        IProductBuilder _productBuilder;
        public ProductCreator(IProductBuilder productBuilder) 
        { 
        _productBuilder = productBuilder;   
        }
        public void CreateProduct()
        {
           
            _productBuilder.SetProductName();
            _productBuilder.SetMRP();
            _productBuilder.SetPid();

        }

        public Products GetProducts()
        {
           return _productBuilder.GetProducts();
        }
    }
    internal class BuilderDesignPatterns
    {
        
        
       
    }
}

