﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FirstProgram
{
   // EXTENSION


    public class DemoConstAndReadonly
    {
        public delegate int PerformCalculation(int x, int y);


        public int Calc(int x, int y)
        {
            return x + y;
        }
        public int Calc1(int x, int y)
        {
            return x + y;
        }
        const double pi = Math.PI;

        readonly double value=0.00;

        public DemoConstAndReadonly(double val) {

            value = val;
            PerformCalculation performCalculation = Calc;
            performCalculation += Calc1;

         // Console.WriteLine(performCalculation(20, 20));

          

        }

        public void Method()
        {
            //value = 200;
        }
    }

   public class DemoMethods
    {
       public void DemoMethodOne()
        {
            Console.WriteLine("This is DemoMthodOne called...");
        }
        public void DemoMethodTwo()
        {
            Console.WriteLine("This is DemoMthodTwo called...");
        }
        public void DemoMethodThree()
        {
            Console.WriteLine("This is DemoMthodThree called...");
        }
    }

  public static class MyExten
    {
        public static void DemoMethodFour(this DemoMethods str)
        {
            Console.WriteLine("Demo Method Four which is extenison method is being called...");
        }
    }

    partial  class MyPartialClass 
    {

        public string? MyProperty { get; set; }

       
        public MyPartialClass() { 
       
        } 

        
    }
    partial class MyPartialClass
    {
       
        public MyPartialClass(string name) {
            MyProperty = name;
        }
    }  



    public static class MyExtension
    {
        public static int WordCount(this string str)
        {
            return str.Length;  
        }
    }



    //public static class MyExtensions
    //{
    //    public static int WordCount(this string str)
    //    {
          

    //        return str.Split(new char[] { ' ', '.', '?' },
    //                         StringSplitOptions.RemoveEmptyEntries).Length;
    //    }
    //}
    public class Pet
    {
        public required int Age;
        public string Name;
    }

    // `Age` field is necessary to be initialized.
    // You don't need to initialize `Name` property

    // var pet = new Pet() { Age = 10 };
    // Compiler error:
    // Error CS9035 Required member 'Pet.Age' must be set in the object initializer or attribute constructor.
    // var pet = new Pet();
    public class Person12
    {
        public string FirstName { get; set; }
        public string LastName { get; init; }
    }

    // The `LastName` property can be set only during initialization. It CAN'T be modified afterwards.
    // The `FirstName` property can be modified after initialization.
    class Age
    {
        public string FirstName { get; init; }
        private readonly int _year;
        Age(int year)
        {
            FirstName = "anc";
            _year = year;

        }
       
        void ChangeYear()
        {
           
            //_year = 1967; // Compile error if uncommented.
        }
    }
    internal class AugustNineteenth
    {
        (int max, int min) DemoTuple(int number)
        {
            return (30, 70);
        }
        public static void AnonymousTypes()
        {
            var t = (1, 2, 3, 4, 5, 6, 7,56);

           

            var person = new { Name = "Alice", Age = 30 };
            Console.WriteLine(person.Name); // Output: Alice
            Console.WriteLine(person.Age);  // Output: 30
            var pet = new Pet() { Age = 30 };
            string demo = "ABC";
    
            DemoOneTwo demoOneTwo = new DemoOneTwo();

           

            
        }
    }
    class Demo
    {

    }
   partial  class DemoOneTwo : Demo
    {
        private static int a = 56;
        partial void Data();

       
    }

    partial  class DemoOneTwo
    {
        public static int b = 1;
        partial void Data()
        {

        }
    }

    partial interface Iface { }

    partial interface Iface { }
}
