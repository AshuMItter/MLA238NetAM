﻿using System.Data.SqlClient;

using System.Data;
using System.Xml.Linq;

namespace ADoDemo
{
    internal class Program
    {
               static string conString = "Server=.;" +
              "Database=Employee;" +
              "Integrated Security=true";
      

        public class Students
        {
            public int Id { get; set; }

            public string Name { get; set; }

            public int Age { get; set; }

            public string Address { get; set; }
        }

        // Adding rows to list using DataReader
        public static void AddingRowsToList()
        { 

            List<Students> students = new List<Students>(); 

            using(SqlConnection con =new SqlConnection(conString))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("Select * from Students", con);
                SqlDataReader sdr = cmd.ExecuteReader();    

                while (sdr.Read()) {
                    Students stud = new Students();
                    stud.Id = sdr.GetInt32(0);
                    stud.Name = sdr.GetString(1);
                    stud.Age = sdr.GetInt32(2);
                    stud.Address = sdr.GetString(3);    
                    students.Add(stud); 
                }
                con.Close();
            }
            foreach (var item in students)
            {
                Console.WriteLine($"The student whose name is {item.Name}, age is  {item.Age} , address is  {item.Address} is registered with an id : {item.Id} " );
            }
        }
        // Concurrency Continues
        public static void HandlingConcurrency()
        {
            using (SqlConnection con = new SqlConnection(conString))
            {

                using (SqlDataAdapter adapter = new SqlDataAdapter("Select * from YourTable", con))
                {

                    SqlCommandBuilder cmdBuiler = new SqlCommandBuilder(adapter);

                    DataSet ds = new DataSet();
                    adapter.Fill(ds);

                    foreach (DataRow row in ds.Tables[0].Rows)
                    {
                        if (row["id"].ToString() == "1")
                        {
                            byte[] originalTimestamp = (byte[])row["CreatedAt"];
                            string updateQuery = "UPDATE YourTable SET product_name=@pName WHERE id = @id AND CreatedAt = @OriginalTimestamp";

                            foreach (var item in originalTimestamp)
                            {
                                Console.WriteLine(item);
                            }

                            using (var command = new SqlCommand(updateQuery, con))
                            {

                                //command.Parameters.Add("@id", SqlDbType.Int).Value = row["id"];

                                //command.Parameters.AddWithValue("@OriginalTimestamp", SqlDbType.Timestamp).Value = originalTimestamp;

                                //command.Parameters.AddWithValue("@pName", SqlDbType.VarChar).Value = "DemoValue";
                                //con.Open();

                                //int result=    command.ExecuteNonQuery();
                                //Console.WriteLine(result);
                                //con.Close();

                                //adapter.UpdateCommand = command;

                                //adapter.Update(ds);

                            }



                        }
                    }

                   // adapter.Update(ds);
                }

            }
        }

        // Concurrency managment using TimeStamp 
        public static void ConCurrency()
        {
            string sql = "INSERT INTO YourTable (product_name, product_description) VALUES (@product_name, @product_description)";
            DateTime manualTimestamp = DateTime.UtcNow; // Adjust as needed

            using (SqlConnection conn = new SqlConnection(conString))
            {
                conn.Open();

                using (SqlCommand cmd = new SqlCommand(sql, conn))
                {
         cmd.Parameters.AddWithValue("@product_name",
     "John Doe");
                    cmd.Parameters.AddWithValue("@product_description", "Value");
                    
                    cmd.ExecuteNonQuery();
                }
            }

            Console.WriteLine("Row inserted successfully!");
        }


    
        static void Main(string[] args)
        {
            SortingViews();
          //  FilterRowState();
          //  Filter();
          //  AdvDis();
          //AddingRowsToList();
          // LoadDataReader();
          // HandlingConcurrency();
          // ConCurrency();
          // LoadDataReader();
          //SortingViews();
          //Filter();
          //FilterRowState();
          //AdvDisc();
          //AdvDis();
          //DisconnectedConcept();
          // UpdateStudentsNameStoredProcedure();
          //CallStoredProcedure();
          //  Disconnected();
          // BrindDataInConnectedArchitecture();
          // UpdateDataConnectArchitecture();
          //RunScalarCommand();
        }

        // Using SqlDataReader to fill DataTable
        public static void LoadDataReader()
        {
            // Add reference to System.Data.SqlClient

            // ... your code to establish a connection and execute a query
            DataTable dataTable = new DataTable();
            // Execute the query and get the SqlDataReader
            using (SqlConnection connection = new SqlConnection(conString))
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand("Select * from Students", connection))
                {
                    SqlDataReader reader = command.ExecuteReader();

                    // Create a DataTable             
                    


                    // Load the data from the SqlDataReader into the DataTable
                    dataTable.Load(reader);

                   
                    // Use the DataTable for further processing

                    // Close the reader (automatically closed by using block)
                }
                connection.Close();
               
            }

            foreach (DataRow item in dataTable.Rows)
            {
                Console.WriteLine($"{item["student_id"]} - {item["student_name"]} - {item["student_age"]}- {item["student_address"]}");
            }
        }
        // DataView Sorting
        public static void SortingViews()
        {
            // Create a DataTable with sample data
            DataTable dt = new DataTable("Customers");

            dt.Columns.Add("CustomerID", typeof(int));
            dt.Columns.Add("Name", typeof(string));
            dt.Columns.Add("City", typeof(string));

            dt.Rows.Add(1, "John Doe", "New York");
            dt.Rows.Add(2, "Jane Smith", "Los Angeles");
            dt.Rows.Add(3, "Mike Johnson", "Chicago");

            // Create a DataView sorted by Name in descending order
            DataView dv = new DataView(dt);
            dv.Sort = "CustomerID ASC";

            // Iterate through the sorted rows
            foreach (DataRowView row in dv)
            {
                Console.WriteLine($"CustomerID: {row["CustomerID"]}, Name: {row["Name"]}");
            }
        }
        // RowFilter by State of the row in DataView 
        public static void FilterRowState() {

            // Create a DataTable with sample data
            DataTable dt = new DataTable("Products");
            dt.Columns.Add("ProductID", typeof(int));
            dt.Columns.Add("Name", typeof(string));
            dt.Columns.Add("Price", typeof(decimal));

            // Add a new row
            DataRow newRow = dt.NewRow();
            newRow["ProductID"] = 4;
            newRow["Name"] = "New Product";
            newRow["Price"] = 19.99;
            dt.Rows.Add(newRow);

            // Create a DataView from the DataTable
            DataView dv = new DataView(dt);

            // Filter only added rows
            dv.RowStateFilter = DataViewRowState.Added;

            // Iterate through the filtered rows
            foreach (DataRowView row in dv)
            {
                Console.WriteLine($"ProductID: {row["ProductID"]}, Name: {row["Name"]}");
            }
        }
        // RowFilter in DataView 
        public static void Filter()
        {


            DataTable dataTable = new DataTable("Students");

            dataTable.Columns.Add("Id", typeof(int));
            dataTable.Columns.Add ("Name", typeof(string));
            dataTable.Columns.Add("City", typeof(string));

            dataTable.Rows.Add(1, "Geerija", "Pune");
            dataTable.Rows.Add(2, "Rohan", "Pune");
            dataTable.Rows.Add(3, "Rustam", "Mumbai");
            dataTable.Rows.Add(4, "Jack", "Pune");


            DataView dv = new DataView(dataTable);

             dv.RowFilter = "Id <  '3'";

            //dv.RowStateFilter = DataViewRowState.Added;

            foreach (DataRowView item in dv)
            {
                Console.WriteLine($"{item["Id"]} - {item["Name"]} - {item["City"]}");
            }


            //DataTable dt = new DataTable("Customers");

            //dt.Columns.Add("CustomerID", typeof(int));
            //dt.Columns.Add("Name", typeof(string));
            //dt.Columns.Add("City", typeof(string));

            //dt.Rows.Add(1, "John Doe", "New York");
            //dt.Rows.Add(2, "Jane Smith", "Los Angeles");
            //dt.Rows.Add(3, "Mike Johnson", "Chicago");

            //// Create a DataView from the DataTable
            //DataView dv = new DataView(dt);

            //// Filter rows where City is "New York"
            //dv.RowFilter = "City = 'New York'";

            // Iterate through the filtered rows
            //foreach (DataRowView row in dv)
            //{
            //    Console.WriteLine($"CustomerID: {row["CustomerID"]}, Name: {row["Name"]}");
            //}
        }

        // Advanced - Disconnected Architecture
        // Creating Constraints and Cardinality in DataSet Datatables
        // Still in progress
        public static void AdvDisc()
        {
            DataSet dataSet = new DataSet();
            //Add Class Table in the dataset    
            DataTable ClassTable = dataSet.Tables.Add("Class");
            ClassTable.Columns.Add("ID", typeof(int));
            ClassTable.Columns.Add("Name", typeof(string));

            //Add Student Table in the dataset    
            DataTable StudentTable = dataSet.Tables.Add("Student");
            StudentTable.Columns.Add("ClassID", typeof(int));
            StudentTable.Columns.Add("ID", typeof(int));
            StudentTable.Columns.Add("Name", typeof(string));

            //Initialize the primary key constraint    
            ClassTable.PrimaryKey = new DataColumn[] { ClassTable.Columns["ID"] };
            dataSet.Relations.Add("Class_Student", StudentTable.Columns["ClassID"], ClassTable.Columns["ID"]);



            DataColumn dcClassID, dcStudentID;
            //gET COLUMNS AND CREATE THE CONSTRAINT    
            dcClassID = dataSet.Tables["Class"].Columns["ID"];
            dcStudentID = dataSet.Tables["Student"].Columns["ID"];

            ForeignKeyConstraint foreignKeyConstraint = new ForeignKeyConstraint("ClassFK", dcClassID, dcStudentID);
            //Setting Rule of constraint    
            foreignKeyConstraint.DeleteRule = Rule.Cascade;
            foreignKeyConstraint.UpdateRule = Rule.Cascade;
            dataSet.EnforceConstraints = false;

            var Class = dataSet.Tables["Class"];

            var classRow = Class.NewRow();

            classRow["ID"] = 1;
            classRow["Name"] = "Dot Net";

            Class.Rows.Add(classRow);


            var classRow1 = Class.NewRow();

            classRow1["ID"] = 2;
            classRow1["Name"] = "Java";

            Class.Rows.Add(classRow1);


            var Student = dataSet.Tables["Student"];
            var studentRow = Student.NewRow();

            studentRow["ID"] = 1;
            studentRow["ClassID"] = 1;
            studentRow["Name"] = "Rahul";

            var studentRow1 = Student.NewRow();

            studentRow1["ID"] = 2;
            studentRow1["ClassID"] = 1;
            studentRow1["Name"] = "Rajneesh";

            Student.Rows.Add(studentRow);
            Student.Rows.Add(studentRow1);

            Console.WriteLine("Class :");
            Console.WriteLine("| Class_ID |  name  | ");
            foreach (DataRow item in Class.Rows)
            {
               
                Console.WriteLine($"|  {item["ID"] } | { item["Name"]}  | ");
            }
            Console.WriteLine("Student :");
            Console.WriteLine("| ID |  ClassID  |  Name ");
            foreach (DataRow item in Student.Rows)
            {
                Console.WriteLine($"|  {item["ID"]} | {item["ClassID"]}  |  {item["Name"]} ");
            }

            foreach (DataRow item in Class.Rows)
            {
                if (item["ID"].ToString() == "1")
                {
                    item.Delete();
                    break;
                }
            }
            Console.WriteLine("Deleting....");
            //dataSet.EnforceConstraints = true;
            Thread.Sleep(1000);

            Console.WriteLine("Class :");
            Console.WriteLine("| Class_ID |  name  | ");
            foreach (DataRow item in Class.Rows)
            {

                Console.WriteLine($"|  {item["ID"]} | {item["Name"]}  | ");
            }
            Console.WriteLine("Student :");
            Console.WriteLine("| ID |  ClassID  |  Name ");
            foreach (DataRow item in Student.Rows)
            {
                Console.WriteLine($"|  {item["ID"]} | {item["ClassID"]}  |  {item["Name"]} ");
            }









            ////Adding constraint to a table    
            //UniqueConstraint custUnique = new UniqueConstraint(new DataColumn[] { ClassTable.Columns["ID"], StudentTable.Columns["Name"] });
            //dataSet.Tables["Class"].Constraints.Add(custUnique);
        }
        // Disconnected Architecture - Create/Update and Delete
        public static void AdvDis()
        {
            using (SqlConnection con = new SqlConnection(conString))
            {

                using (SqlDataAdapter adapter = new SqlDataAdapter("Select * from Students", con))
                {

                    SqlCommandBuilder cmdBuiler = new SqlCommandBuilder(adapter);

                    DataSet ds = new DataSet();
                    adapter.Fill(ds);

                    var Students = ds.Tables[0];


                    // update
                    foreach (DataRow row in Students.Rows)
                    {
                        if (row["student_id"].ToString() == "2")
                        {
                            Console.WriteLine("First "+row.RowState);
                            row["student_name"] = "Demo";
                            Console.WriteLine("After update "+row.RowState);
                            // delete
                            // row.Delete();
                            break;
                        }
                    }
                    //delete
                    foreach (DataRow row in Students.Rows)
                    {
                        if (row["student_id"].ToString() == "1016")
                        {
                            Console.WriteLine("Before Delete "+row.RowState);
                            row.Delete();
                            Console.WriteLine("After Delete "+row.RowState);
                            break;
                        }
                    }
                    // create
                    var studentRow = Students.NewRow();

                    studentRow["student_name"] = "Roshan";
                    studentRow["student_age"] = 36;
                    studentRow["student_address"] = "Pune";

                    Students.Rows.Add(studentRow);
                    Console.WriteLine("After adding a row "+studentRow.RowState);

                  //  Students.AcceptChanges();

                  //  Console.WriteLine(studentRow.RowState);

                    adapter.Update(ds);
                }

            }
        }
        public static void DisconnectedConcept()
        {
            using(SqlConnection con = new SqlConnection(conString)) { 
            
                using (SqlDataAdapter adapter = new SqlDataAdapter("Select * from Students", con))
                {
                
                    SqlCommandBuilder cmdBuiler = new SqlCommandBuilder(adapter);

                    DataSet ds = new DataSet();
                    adapter.Fill(ds);

                    var Students =  ds.Tables[0];

                    //// update
                    //foreach (DataRow row in Students.Rows)
                    //{
                    //    if (row["student_id"].ToString() == "1012")
                    //    {
                    //        row["student_name"] = "Rozana";
                    //        // delete
                    //        row.Delete();
                    //        break;
                    //    }
                    //}
                    // delete
                    foreach (DataRow row in Students.Rows)
                    {
                        if (row["student_id"].ToString() == "1013")
                        {

                            row.Delete();
                            break;
                        }
                    }
                    //// create
                    //var studentRow = Students.NewRow();

                    //studentRow["student_name"] ="Roshan";
                    //studentRow["student_age"] = 36;
                    //studentRow["student_address"] = "Pune";

                    //Students.Rows.Add(studentRow);


                    adapter.Update(ds);
                }
                    
            }

        }

        // Calling SP or Stored Procedures from Ado.Net 
        public static void UpdateStudentsNameStoredProcedure()
        {
           using(SqlConnection conn = new SqlConnection(conString))
            {

                conn.Open();
                using (SqlCommand cmd = new SqlCommand("UpdateStudentsName", conn))
                {

                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add("@id",SqlDbType.Int).Value = 7;
                    cmd.Parameters.Add("@name", SqlDbType.VarChar).Value = "DemoTesting";

                    int result = cmd.ExecuteNonQuery();
                    Console.WriteLine($"{result} row(s) affected...");
                    
                }
                conn.Close();
            }
            
            
        }

        // Connected Architecture Scalar Commannd
        public static void RunScalarCommand()
        {
            using(SqlConnection con = new SqlConnection(conString))
            {

                con.Open();

                using (SqlCommand cmd = new SqlCommand("select avg(student_age) as AverageAge from Students", con))
                {
                    var result = cmd.ExecuteScalar();
                    Console.WriteLine(result);
                }
                con.Close();
            }
        }
        // connected Architecture Update Command
        public static void UpdateDataConnectArchitecture()
        {
            using (SqlConnection sqlConnection = new SqlConnection(conString))
            {
                sqlConnection.Open();
                SqlCommand cmd = new SqlCommand("update Students set student_name=@name where student_id=@id", sqlConnection);
                cmd.Parameters.Add("@name",SqlDbType.VarChar).Value = "DemoName";
                cmd.Parameters.Add("@id", SqlDbType.Int).Value = 8;

                int result = cmd.ExecuteNonQuery();
                if(result > 0) {
                    Console.WriteLine("Update succesfuuly implemented");
                }else
                {
                    Console.WriteLine("Not done !");
                }
             
                Console.WriteLine(result);
                sqlConnection.Close();  

            }
        }

        // Bringing data to Console App using Connected Architecture
       public static void BrindDataInConnectedArchitecture()
        {
            using (SqlConnection sqlConnection = new SqlConnection(conString))
            {
                sqlConnection.Open();

                using (SqlCommand cmd = new SqlCommand("Select * from Students", sqlConnection))
                {
                    using(SqlCommand cm2 = new SqlCommand("update Students set student_name=@name where student_id=@id ", sqlConnection))
                    {
                        SqlDataReader reader2 = cmd.ExecuteReader();

                        while (reader2.Read())
                        {

                            Console.WriteLine($"[{reader2.GetInt32(0)} " +
                                $"| {reader2.GetString(1)}" +
                                $" | {reader2.GetInt32(2)} | " +
                                $"{reader2.GetString(3)}]");
                        }
                    }

                    SqlDataReader reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {

                        Console.WriteLine($"[{reader.GetInt32(0)} " +
                            $"| {reader.GetString(1)}" +
                            $" | {reader.GetInt32(2)} | " +
                            $"{reader.GetString(3)}]");
                    }
                }
                sqlConnection.Close();
            }

          

           


        }
        static void Disconnected()
        {
           

            //DataTable dt = new DataTable("Students");

            //dt.Columns.Add("student_id");
            //dt.Columns.Add("student_age");
            //dt.Columns.Add("student_name");
            //dt.Columns.Add("student_address");

            //DataRow dr = dt.NewRow();

            //dr["student_id"] = 8;
            //dr["student_age"] = 20;

            //dr["student_name"] = "Remo";

            //dr["student_address"] = "Pune";

            //dt.Rows.Add(dr);

            //dataSet.Tables.Add(dt); 

            using(SqlConnection conn = new SqlConnection(conString))
            {
                conn.Open();
                SqlDataAdapter sda = new SqlDataAdapter("Select * from Students",conn);
                conn.Close();

                SqlCommandBuilder sdaBuilder = new SqlCommandBuilder(sda);
                DataSet dataSet = new DataSet(); 
                sda.Fill(dataSet);

               // dr["student_address"] = "Dubai";
               DataTable dt = dataSet.Tables[0];

               DataRow dr = dt.NewRow();

                // updating
                foreach (DataRow item in dt.Rows)
                {
                    if (item["student_id"].ToString() == "2")
                    {
                        item["student_age"] = 20;
                        item["student_name"] = "Remo";
                        item["student_address"] = "Pune";
                        break;
                    }
                }
                // deleting
                foreach (DataRow item in dt.Rows)
                {
                    if (item["student_id"].ToString() == "1010")
                    {
                        item.Delete();  
                    }
                }

                // creating
                // dr["student_id"] = 9;
                //dr["student_age"] = 20;
                //dr["student_name"] = "Remo";
                //dr["student_address"] = "Pune";

                //dt.Rows.Add(dr);




              //  sda.Update(dataSet);
                
            }


        }
        // Update using Connected Architecture
        static void UpdateData()
        {
            SqlConnection connection = new SqlConnection(conString);

            try
            {
                // Open the connection
                connection.Open();
                
                Console.WriteLine("Connection opened successfully!");
                
                SqlCommand cmd = new SqlCommand("Update Students " +
                    "set student_name=@name " +
                    "where student_id=@id ",connection);

               
              
                cmd.Parameters.AddWithValue("@name", "Subhash");
                // cmd.Parameters.Add("@name", SqlDbType.VarChar).Value = "Demo";
                cmd.Parameters.AddWithValue("@id", 2);

                int result = cmd.ExecuteNonQuery();
                Console.WriteLine(result);
                // Close the connection (always recommended to release resources)
            }
            catch (SqlException ex)
            {
                Console.WriteLine($"Error connecting to database: {ex.Message}");
            }
            finally
            {

                if (connection != null)
                {
                    connection.Close(); // Ensure connection is closed even on exceptions
                }
            }

        }
        // Only one command allowed per open connection if MARS not enabled
        static void SelectData()
        {
           
            // Add reference to System.Data.SqlClient

            // Replace with your connection string details
            // string connectionString = "Data Source=localhost;Initial Catalog=MyDatabase;Integrated Security=True";


            // Create a SqlConnection object
            SqlConnection connection = new SqlConnection(conString);

            try
            {
                // Open the connection
                connection.Open();
                Console.WriteLine("Connection opened successfully!");
                SqlCommand cmd = new SqlCommand("Select * from Students", connection);
                SqlCommand cmd2 = new SqlCommand("Select * from Students", connection);

                // SqlDataReader reader2 = cmd2.ExecuteReader();
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    Console.WriteLine($"{reader.GetInt32(0)} {reader.GetString(1)} {reader.GetInt32(2)} {reader.GetString(3)}");
                }
                // Perform data access operations (explained in subsequent sections)
                reader.Close();

                // Close the connection (always recommended to release resources)
            }
            catch (SqlException ex)
            {
                Console.WriteLine($"Error connecting to database: {ex.Message}");
            }
            finally
            {

                if (connection != null)
                {
                    connection.Close(); // Ensure connection is closed even on exceptions
                }
            }

        }

        // Calling Stored Procedures from Ado.Net 
        static void CallStoredProcedure()
        {
            SqlConnectionStringBuilder sqlConnectionStringBuilder = new SqlConnectionStringBuilder();
            sqlConnectionStringBuilder.DataSource = "demo";
            Console.WriteLine(sqlConnectionStringBuilder.ConnectionString);
            using (SqlConnection connection = new SqlConnection(conString))
            {
                connection.Open();  
                using(SqlCommand command = new SqlCommand("UpdateStudentsName",connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add("@name", SqlDbType.VarChar).Value="Siddharth";
                    command.Parameters.Add("@id",SqlDbType.Int).Value=2;
                    command.ExecuteNonQuery();
                }
                connection.Close() ;
            }

        }
        
    }
}
