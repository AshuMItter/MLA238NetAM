import { Component } from '@angular/core';
import { generate } from 'rxjs';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-template-driven-form',
  templateUrl: './template-driven-form.component.html',
  styleUrls: ['./template-driven-form.component.css']
})
export class TemplateDrivenFormComponent 
{

  student_registration={

    fName: '',
    mName: '',
    lName: '',
    age: 0,
    dob: new Date(),
    gender: '',
    course_enrolled: '',
    

  }
  submitForm(){

  }
  
}
interface StudentDetails {

  fName:string;
  mName:string;
  lName:string;
  age:number;
  dob:Date;
  gender:string;             
  course_enrolled:string;                    
}

